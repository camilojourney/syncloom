# Prospective scope/criteria amendment for frontend challenge

2026-11-02. Authority: owning firstmate applying the existing Main1304 and Main1312 instructions, not a new user preference or a retroactive change to experiment results. Preserve the original frozen packet, choices and measurements unchanged. This amendment is recorded after that experiment and before the independent challenge/implementation; compare options under both the original and amended readings and disclose the timing.

## Actual authorized finish line

The request is to write, review and see text posts first, using Impeccable and Decide. Main1312 requires every created page to receive design/critique/audit and screenshots, and every API endpoint to be tested with synthetic data, including its actual consuming page where one exists. That does not by itself require creating a new browser form for every API route or expanding the first text slice into images, all platforms' account setup, or worldwide authentication.

- Preserve existing render routes and assets when styling shared components, but do not build new image/carousel workflows in this first text slice.
- Editable credential entry, OAuth connection management and new auth-boundary route classification are security-sensitive, not an automatic consequence of an endpoint coverage table. The worldwide-auth request is separately a knowledge-only audit; no conclusion or implementation from it is assumed here. If a connection-status surface is useful, distinguish a read-only local status view from new sign-in/refresh/sign-out actions. New security-sensitive behavior requires its own explicit owner review before landing.
- Keep the API worker's method/path matrix authoritative for executed API coverage. Existing script-free HTML form adapters call the Rust core; do not relabel them as JSON API consumers. A route can correctly have no browser consumer, with that fact explicit in the table.

## Acceptance corrections to assess without hiding the original frame

1. CSP, revision approval and containment remain hard boundaries. Offline/hermetic reproducibility is a real constraint, but determine whether 'zero new dependencies' is actually required by the adopted project contract or merely a preference; do not reject a maintainable alternative only for development convenience or an uncached first fetch.
2. Every actual lifecycle state must retain its canonical meaning, including contained versus posted, exported versus posted, and publishing/unknown versus a definite refusal or rejection. Six distinct colors are only a structural signal, not proof of truthful state semantics. No blind retry of a possibly successful post.
3. Show conservative app limits and dated estimates as such. Local core rules do not independently verify current external platform limits, fonts, fold positions or exact remote layout. Preserve exact post text and label approximate local previews honestly.
4. The first local text experience must have no clipped labels/buttons, readable light/dark layouts and keyboard/error proof across all created/touched pages. The final screenshot matrix follows the actual screen inventory, not an unexamined requirement to add six pages.

The challenger must identify framing problems and consequential dependencies, not merely grade agreement with the primary choices. Any proposed adjustment needs reasons and preserved original outcomes. The primary recommendation remains withheld until the challenger's initial picks are saved.
