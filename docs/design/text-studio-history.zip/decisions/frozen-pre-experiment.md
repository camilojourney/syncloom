# Frozen Pre-Experiment Briefs, Acceptance Criteria, and Experiment Protocol

Frozen at: `2026-11-02T14:04:00Z` (before executing the browser palette/type comparison experiment)
Method: `decide@1.3.1`, source `baa7c65c88fa04eaa2d2167e78b24ff56e575e68`
Checklist: `1.0.0`, SHA256 `8c88c2c9c524d97552f67f30f6c4ba25589516b9dc18a51b09f7962688e5b056`

---

## Decision 1: `frontend/0007-text-studio-frontend-stack`

### 1. Brief (Checklist Q1-Q5)
- **Q1 Decision:** Choose the frontend rendering and interaction architecture for `syncloom.v2`'s studio across all 6 browser pages (Studio Workspace & Post Ledger, Piece Review & Platform Previews, Edit Draft, Render Previews, Platform Connections & Delivery Boundaries, and Error/Recovery). Desired outcome: a fast, accessible, maintainable frontend that covers every loopback API operation and preserves all `syncloom-core` invariants and `syncloom-server` security headers without inventing backend state. Owner: delegated engineering decision within the captain's standing Rust-first rule (ADR-0001 D1/D6, `docs/vision.md` 1.2), with independent different-family challenge commissioned by the supervisor because UI stack changes are consequential across all routes and E2E tests.
- **Q2 Options:**
  - **S1 (Modularized Axum Server-Rendered HTML + CSS in `syncloom-server`):** Retain and refactor the zero-dependency Rust HTML/CSS rendering in `crates/syncloom-server/src/page.rs` into cohesive submodules (`page/mod.rs`, `page/home.rs`, `page/review.rs`, `page/previews.rs`, `page/connections.rs`, `studio.css`), using native HTML forms (`GET`/`POST`) and URL query parameters (`/?status=...&channel=...`).
  - **S2 (Typed Compile-Time Rust Template Crate in `syncloom-server`, e.g. `askama` or `maud`):** Server-rendered HTML via third-party proc-macro templates in `syncloom-server`, keeping script-free browser delivery.
  - **S3 (Rust-to-WASM Client/Isomorphic Framework, e.g. `Leptos` or `Dioxus` Web):** Compile Rust UI components to WebAssembly (`wasm32-unknown-unknown`) with JS hydration/glue talking to `/v1/*` JSON routes.
  - **S4 (JavaScript/TypeScript SPA, e.g. Next.js/React or Vite):** Separate JS/TS frontend bundle talking to `/v1/*` JSON routes, similar to the old `observatory/frontend`.
  - **Excluded:** Native-only desktop shells (`Tauri`, `egui`, `GPUI`, `Iced`) are excluded because ADR-0001 D1 already rejected desktop-only in favor of a browser page served by the Rust core.
- **Q3 Constraints (Hard vs Preference):**
  - *Hard H1 (Language & First-Party Rule):* All first-party code must be Rust (`docs/vision.md` 1.2, `docs/decisions/0001-syncloom-v2-rebuild-decisions.md`).
  - *Hard H2 (Script-Free CSP & Session Boundary):* `crates/syncloom-server/src/boundary.rs:94` and `openspec/specs/studio-api/spec.md` enforce `Content-Security-Policy: default-src 'none'; script-src 'none'; style-src 'self' ...`, no-CORS, exact `Host`/`Origin`, and CSRF tokens in forms. Main explicitly ruled in `openspec/changes/polish-social-review/proposal.md`: *"script-free - keep CSP script-src 'none' and the landed no-script rule."*
  - *Hard H3 (Offline Nix Build & Hermetic Single-Command Gate):* `openspec/specs/studio-api/spec.md` ("Repository checks" and "Hermetic tests") and `docs/development.md` require `cargo fmt --check && cargo clippy --all-targets -- -D warnings && cargo test` to pass hermetically in the cached Nix shell without network fetches or `node_modules`.
- **Q4 Current Numbers:**
  - `crates/syncloom-server/src/page.rs`: 636 lines of Rust (measured).
  - `crates/syncloom-server/src/studio.css`: 552 lines of CSS (measured).
  - Workspace dependencies in `Cargo.toml`: 26 crates; 0 template/WASM crates cached in `Cargo.lock` (measured).
  - Existing browser integration test suite `crates/syncloom-server/tests/review_screen.rs`: 926 lines testing server-rendered HTML responses and form POSTs directly over loopback HTTP without requiring a JS runtime (measured).
- **Q5 What Changes the Answer:**
  - If any required studio interaction across the 6 pages (multi-channel drafting, status/channel filtering, draft editing, platform-specific previewing, revision-bound approval/rejection/reopening, X cost consent, publish/dry-run/manual-export, or platform connection management) were impossible without client-side JavaScript or WASM, H2 would need escalation to Main/captain. If all required interactions work via standard HTML forms (`POST`) and query-filtered navigation (`GET`), S1/S2 satisfy every functional requirement without reopening H2.

### 2. Frozen Acceptance Criteria (Decision 1)
- **C1.1 (CSP & Boundary Compliance - Pass Mark: 100%):** Preserves `script-src 'none'`, exact `Host`/`Origin` checks, and CSRF form validation in `boundary.rs` with zero regressions in `crates/syncloom-server/tests/`.
- **C1.2 (Offline Nix & Hermetic Build - Pass Mark: 0 uncached crates / 0 external toolchains):** Compiles and passes `cargo fmt --check && cargo clippy --all-targets -- -D warnings && cargo test` using only the cached `Cargo.lock` and Nix Rust 1.98.1 toolchain.
- **C1.3 (Complete Operation & Endpoint Coverage - Pass Mark: 100% of loopback API capabilities reachable script-free):** Supports (1) multi-channel thought drafting, (2) queue filtering by lifecycle/channel and cursor pagination, (3) draft text editing, (4) status transitions (`approve`, `reject`, `reopen` to `pending_review`), (5) X dated cost consent, (6) explicit publish and dry-run with truthful receipt, (7) manual export bundle creation (`reddit`/`tiktok`), and (8) platform connection inspection/sign-in/refresh/sign-out across LinkedIn, X, Bluesky, Threads, Mastodon, and Meta, all without client-side script execution.
- **C1.4 (Maintainability & Single Owner per Rule - Pass Mark: 0 duplicated validation rules):** `syncloom-core::Studio` remains the sole owner of domain rules, limits, revisions, and HTML escaping (`syncloom_core::html::escape`).

---

## Decision 2: `frontend/0008-text-studio-palette-and-typography`

### 1. Brief (Checklist Q1-Q5)
- **Q1 Decision:** Choose the visual color palette (light and dark themes) and typography system for `syncloom.v2`'s studio across all 6 pages. Desired outcome: comfortable long-post reading (up to 3,000 characters) in both light and dark modes, verified WCAG AA contrast across all states, unmistakable semantic differentiation across draft (`pending_review`), `approved`, `contained`, `exported`, `posted`, and `rejected`/`failed`/`unknown` states, and faithful platform text previews for LinkedIn, X, Bluesky, and Threads. Owner: delegated engineering/design decision within the captain's prompt (*"use impecable skill to create it, you wouold think about the design with argos, you can use the tool /decision to check colors we need to optimize for what we want and a great experience for me so I can see what I post. let' focus on the text first"*).
- **Q2 Options:**
  - **B0 (Incumbent Baseline):** Current `studio.css` (light-only `#f6f7f2` / `#215c49`, identical green `.status` pill for all states, fluid `clamp(32px, 4vw, 52px)` headings, uppercase kickers).
  - **P1 (Warm Editorial Atelier - Stone & Terracotta-Amber, Serif Draft + Sans UI + Mono Data):** Parchment `#F7F4EF` / Obsidian `#121110`, terracotta-rust accent `#9A3412` / `#EA580C`, transitional serif (`Iowan Old Style`/`Charter`/`Georgia`) at `16.5px` for draft reading, system sans for UI and platform previews.
  - **P2 (Precision Ink & Mineral Botanical - Warm Alabaster & Deep Slate-Pine / Carbon-Pine & Mint-Sage, Unified Neo-Grotesque Sans + Tabular Mono):** Warm mineral paper `#F5F6F3` / deep carbon-pine `#0D1312`, elevated surface `#FFFFFF` / `#141D1B`, second neutral layer `#EBEEE9` / `#1B2624`, deep pine action `#1B5442` (light) / mint-emerald `#34D399` with `#091E16` ink (dark), 6 distinct semantic state badges (Amber draft, Emerald approved, Indigo contained, Cyan exported, Solid Forest/Mint posted, Crimson rejected/alert), fixed rem scale (`16px` body floor, `60-68ch` measure) in unified system Neo-Grotesque sans plus tabular monospace for hashes/counts.
  - **P3 (High-Chroma Cobalt Command - Cool Slate & Electric Indigo, Compact Sans + Heavy Mono):** Cool slate `#F8FAFC` / deep navy `#090D16`, electric indigo accent `#4F46E5` / `#6366F1`, compact `14px` body copy, monospace section headers and metadata.
- **Q3 Constraints:**
  - *Hard H1 (CSP Font Constraint):* Must work under `default-src 'none'; style-src 'self'` without remote font fetches (`fonts.googleapis.com` is forbidden by CSP and privacy boundaries).
  - *Hard H2 (WCAG AA Contrast):* Body and secondary text >= `4.5:1`; large text, UI controls, focus indicators, and badge borders/icons >= `3.0:1` in BOTH light and dark modes (Impeccable `craft-floor.md` and `colorize.md`).
  - *Hard H3 (Truthful Lifecycle Semantics):* Must visually separate `Pending review` (draft), `Approved` (ready), `Contained` (local outbox only, nothing sent), `Exported` (local bundle only), `Posted` (confirmed remote post ID), and `Rejected`/`Failed`/`Unknown` using both color and non-color cues (icon/shape + explicit label).
  - *Hard H4 (No Truncated Words or Buttons & Responsive 1440px/390px):* Zero horizontal overflow (`scrollWidth <= clientWidth`), zero mid-word truncation, and comfortable `45-75ch` reading measure on desktop.
- **Q4 Current Numbers:**
  - Incumbent `studio.css` has 0 dark-mode rules (`color-scheme: light`), 1 status badge style for 3 statuses, `15px` body font-size (below Impeccable's `16px` floor), and `clamp(32px, 4vw, 52px)` `h1`.
- **Q5 What Changes the Answer:**
  - Measured contrast, line-measure (`ch`), or preview fidelity in the bounded Chrome rendering experiment: any option failing WCAG AA (`4.5:1` text / `3.0:1` UI), failing dark-mode legibility, causing semantic collision between primary actions, platform chrome, and status badges, or causing layout overflow at `1440x900` or `390x844` is eliminated.

### 2. Frozen Acceptance Criteria (Decision 2)
- **C2.1 (Structural & Responsive Integrity - Pass Mark: 0 overflow, 45-75ch desktop reading measure, >= 16px body prose):** Desktop draft & preview columns measure `45-75ch`; body/draft font-size >= `16px`; `scrollWidth <= clientWidth` at both `1440x900` and `390x844` with zero truncated words or buttons.
- **C2.2 (Accessibility & Contrast - Pass Mark: 100% pairs >= WCAG AA in Light & Dark):** Every computed foreground/background text pair >= `4.5:1` (normal text) and >= `3.0:1` (large text/focus/controls) across both Light and Dark themes, verified via browser computed styles; every status badge carries a distinct non-color prefix/shape in addition to color.
- **C2.3 (Semantic Clarity Across Lifecycle States - Pass Mark: 6/6 states visually distinct and non-colliding with primary CTA):** `Pending review`, `Approved`, `Contained`, `Exported`, `Posted`, and `Rejected`/`Failed`/`Unknown` each have distinct hue/luminance/iconography and do not collide with the primary action button or platform brand headers.
- **C2.4 (Platform Preview Fidelity & Impeccable Craft Floor - Pass Mark: 4/4 platforms faithful to verified core rules, 0 craft-floor bans):** Previews for LinkedIn, X, Bluesky, and Threads use platform-matching sans typography, display exact verified `syncloom-core` unit counters (`3000 chars`, `280 weighted units` + dated cost estimate, `300 graphemes / 3000 bytes`, `500 UTF-8 bytes` text-only), make zero unverified platform layout claims, and violate zero Impeccable `craft-floor.md` bans (no `.eyebrow` kickers, no `01 /` numbered markers, no ghost cards, no decorative monospace).

### 3. Bounded Experiment Protocol (Artifact 6)
- **Decisive Question:** How do `B0`, `P1`, `P2`, and `P3` perform on computed WCAG contrast ratios, reading measure (`ch` and `px` line-height), status badge discriminability, and platform preview fidelity when rendered in regular Chrome (`1440x900` and `390x844`, Light and Dark)?
- **Baseline:** `B0` (incumbent `studio.css`).
- **Prior Pass Mark:** Must pass all four frozen criteria `C2.1`-`C2.4` in both Light and Dark at `1440x900` and `390x844`.
- **Safety / Time / Cost Cap:** Local HTML/CSS test page served on loopback (`127.0.0.1`) in `/tmp/fm-syncloom-text-ui-design/`, inspected in one owned Chrome tab via `chrome-devtools-axi`; max 5 minutes wall time, USD 0 external cost, 0 external network requests.
- **Stop Rule & Rollback:** Run one deterministic pass across `B0`, `P1`, `P2`, `P3`; record all computed metrics and screenshots (including failures) without retrying to force a winner; close the test tab on completion.
