# Primary Agent Recommendation Packet (Reveal Only After Challenger's Initial Pick)

**Author:** `syncloom-text-ui-design` (`antigravity/gemini-4-argon`)
**Method:** `decide@1.3.1`, source `baa7c65c88fa04eaa2d2167e78b24ff56e575e68`

---

## 1. Recommended Choice for Decision 1 (`frontend/0007-text-studio-frontend-stack`)

- **Recommendation:** **Option S1 (Modularized zero-dependency Rust server-rendered HTML and CSS in `crates/syncloom-server/src/page/` + `studio.css`)**.
- **Criterion-Based Defense:**
  - **C1.1 (CSP & Boundary):** Preserves `Content-Security-Policy: default-src 'none'; script-src 'none'; style-src 'self' ...`, exact `Host`/`Origin` validation, and `csrf` hidden form fields in `boundary.rs` (`openspec/changes/polish-social-review/proposal.md`). Options S3 (WASM) and S4 (JS SPA) fail C1.1.
  - **C1.2 (Offline Nix & Hermetic Build):** Uses only existing crates in `Cargo.lock` (`axum`, `syncloom-core`, `url`, `serde`). Options S2 (`askama`/`maud`), S3 (`leptos`/`dioxus`), and S4 (`node_modules`) fail C1.2 because none of those dependencies or toolchains exist in `Cargo.lock` or the locked Fleet Nix Rust 1.99.1 profile.
  - **C1.3 (Complete Operation Coverage):** Multi-channel thought intake (`<input type="checkbox" name="channels" value="...">`), queue filtering (`GET /?status=...&channel=...`), draft editing (`POST /review/{id}/edit`), status transitions (`POST /review/{id}/approve|reject|reopen`), X cost consent (`POST /review/{id}/accept-cost`), publish/dry-run (`POST /review/{id}/publish|dry-run`), manual export (`POST /review/{id}/export`), visual rendering (`POST /review/{id}/render`), and platform connection status/actions (`GET /connections`, `POST /connections/{platform}/{action}`) all work via native HTML forms.
  - **C1.4 (Single Owner & Maintainability):** Splitting `crates/syncloom-server/src/page.rs` into `page/mod.rs`, `page/home.rs`, `page/review.rs`, `page/previews.rs`, and `page/connections.rs` prevents Code Verify complexity growth while keeping `syncloom_core::html::escape` as the single HTML escaping owner.

---

## 2. Recommended Choice for Decision 2 (`frontend/0008-text-studio-palette-and-typography`)

- **Recommendation:** **Option P2 (`Precision Ink & Mineral Botanical` palette with unified Neo-Grotesque Sans and Tabular Monospace)**.
- **Criterion-Based Defense:**
  - **C2.1 (Structural & Typographic Integrity):** Uses `16px` (`1rem`) body/draft prose floor (`26.88px` / `1.68` line-height in light, `1.72` in dark, `611px` / `~64ch` width) and a fixed `rem` scale (`12px`, `14px`, `16px`, `18px`, `24px`), with `overflowX: false` at both `1440x900` and `390x844`. `B0` (`15px` + fluid `clamp()`) and `P3` (`14px`) fail C2.1.
  - **C2.2 (Accessibility & Contrast):** Achieves `16.81:1` (Light) / `15.05:1` (Dark) prose contrast, `8.05:1` (Light) / `7.60:1` (Dark) secondary text contrast, `8.77:1` (Light) / `9.04:1` (Dark) primary CTA contrast, and `5.88:1`-`12.98:1` across all 6 lifecycle badges. `B0` fails dark mode completely; `P3` fails dark-mode CTA contrast (`4.47:1` < `4.5:1`).
  - **C2.3 (Semantic Clarity Across Lifecycle States):** All 6 lifecycle states (`○ Pending review` Amber, `✓ Approved` Light-Emerald, `▣ Contained` Indigo, `◫ Exported` Cyan, `● Posted` Solid-Forest/Mint, `× Rejected / ! Alert` Crimson) have distinct backgrounds (`distinctBadgeBgCount: 6`), borders, and symbols, and do not collide with the deep pine (`#1B5442`) / mint (`#34D399`) primary CTA. `P1`'s terracotta CTA (`#9A3412`/`#EA580C`) collides with warm amber/red badges; `P3`'s indigo CTA (`#4F46E5`/`#6366F1`) collides with the `Contained` badge.
  - **C2.4 (Platform Preview Fidelity & Impeccable Craft Floor):** Unified Neo-Grotesque system sans (`-apple-system, BlinkMacSystemFont, "SF Pro Text", "Segoe UI", system-ui, sans-serif`) matches what LinkedIn, X, Bluesky, and Threads render on macOS, avoiding `P1`'s serif-to-sans wrap discrepancy (`587px` vs `611px`) and `P3`'s banned decorative monospace headers.

---

## 3. Second-Round Challenger Prompt (After Reveal)

Given the primary agent's recommendations (**Option S1** for Stack and **Option P2** for Palette/Typography):
1. What is the strongest competing option or failure mode that could falsify **S1** or **P2** during implementation in `syncloom-text-ui`?
2. Which specific implementation detail in **S1** (e.g., `url::form_urlencoded` parsing of repeated `channels` checkboxes in `page.rs` vs `axum::Form`, or server-session state for connection consent URLs) is most likely to cause a subtle bug if not specified explicitly?
3. What simpler procedure or token reduction could achieve the same accessibility and clarity with less CSS or Rust code?
