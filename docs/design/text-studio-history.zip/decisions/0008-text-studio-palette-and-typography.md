# 0008: Provisional Precision Ink and Mineral Botanical palette with system sans and two-axis state labels

Status: proposed (independent challenge completed at `data/syncloom-text-ui-challenge/report.md`, SHA256 `3b148c7badae7a95d66068e1d40d68cdfd0ff1370b5fb3c2baf782b51823efa6`)
Owner: syncloom-v2-lab (delegated engineering/design choice under Captain prompt Main1304/Main1312)
Method: decide@1.3.1, source baa7c65c88fa04eaa2d2167e78b24ff56e575e68
Checklist: 1.0.0, SHA256 8c88c2c9c524d97552f67f30f6c4ba25589516b9dc18a51b09f7962688e5b056
Identity: frontend/0008-text-studio-palette-and-typography
OpenSpec: [polish-social-review](../../../openspec/changes/polish-social-review/proposal.md) (current baseline; implementation change `add-text-studio-frontend` to link back on creation)
Evaluation: executed bounded specimen check in Chrome 156 (`palette-experiment/metrics-*.json` and `comparison-*.png`) at `c0584e87a808f457bd7b205da3009c485243d4e0` and completed independent challenge (`data/syncloom-text-ui-challenge/initial.md` SHA256 `bf962ca53fc2aa1504139447cf380539f0f8ca5f26e51136750c7fbfee902108`; `second-round-objections.md` SHA256 `140a044d50b8fa5d5dfbffff5f5f436303e019b6a259288a05013490cda65152`; `report.md` SHA256 `3b148c7badae7a95d66068e1d40d68cdfd0ff1370b5fb3c2baf782b51823efa6`)

## 1. Brief
Written at: `2026-11-02T14:04:00Z` (before executing the browser palette/type comparison experiment)
Capture: consequential; pre-evaluation packet `decisions/frozen-pre-experiment.md` SHA256 `fec3e3b027d05a7c56daac9a1f128033adae66d54dae01137f7e78f97c638481`; brief revision `c0584e87a808f457bd7b205da3009c485243d4e0`; outcome date `2026-11-16` observed via `crates/syncloom-server/src/studio.css` and `chrome-devtools-axi` product captures; capture order 2 of 2 in task `syncloom-text-ui-design`.
Brief: Apply checklist Q1-Q5 ([frozen brief](frozen-pre-experiment.md#decision-2-frontend0008-text-studio-palette-and-typography)). Choose a provisional visual color palette (light and dark themes) and typography direction for `syncloom.v2`'s text-first browser studio across the supported routes (`GET /`, `GET /review/{piece_id}`, `GET /review/{piece_id}/edit`, plus compatible styling of `GET /review/{piece_id}/render` and shared HTML error pages), optimizing for long-post reading comfort, WCAG AA/AAA contrast, truthful two-axis lifecycle state representation (`Piece.status` and `Piece.publish_status`), and honest approximate local text previews.
Class: consequential; establishes the design system tokens, light/dark accessibility contract, and state display rules across the browser studio screens.
Rollback mechanism/cost and residual harm: Token and CSS changes in `crates/syncloom-server/src/studio.css` are reversible by a single file revert with zero data or API schema impact; however, shipping poor contrast or ambiguous `contained` / `exported` / `unknown` / `posted` labels risks operator misreading of whether a piece was actually published to a live social network.
Process budget: 1 bounded browser specimen pass in regular Chrome via `chrome-devtools-axi` (< 5 minutes wall time, USD 0 external cost) plus 1 independent blind challenger review (`openai-codex/gpt-6.1-sol`). Do not rerun the specimen to chase favorable numbers; prove final quality on the actual built product screens.
Human preference, separate from evidence: The captain requested `"use impecable skill to create it, you wouold think about the design with argos, you can use the tool /decision to check colors we need to optimize for what we want and a great experience for me so I can see what I post. let' focus on the text first"` and `"remember to use impecable and thin on all the pagest we need to create, test all the api points. make it better"`.
Relevant unexplored gaps: No human reading-speed, comprehension, color-vision deficiency task, or live remote platform comparison was run; measurements are limited to sampled Chrome 156 computed styles on macOS (`1440x900` and `390x844`).

## 2. Frozen acceptance
Freeze: `2026-11-02T14:04:00Z`, immutable artifact [frozen-pre-experiment.md](frozen-pre-experiment.md) (SHA256 `fec3e3b027d05a7c56daac9a1f128033adae66d54dae01137f7e78f97c638481`).
Original frozen criteria/pass marks:
- **C2.1 (Structural & Typographic Integrity):** Body/draft prose font-size >= `16px` (`1rem`); desktop reading measure `45-75ch`; fixed `rem` scale; `scrollWidth <= clientWidth` at `1440x900` and `390x844`; works under `default-src 'none'; style-src 'self'`.
- **C2.2 (Accessibility & Contrast):** 100% of computed normal-text foreground/background pairs >= `4.5:1` and large-text/control/focus pairs >= `3.0:1` in BOTH Light and Dark modes, plus non-color indicators on every status badge.
- **C2.3 (Semantic Clarity Across Lifecycle States):** Originally framed as 6 distinct lifecycle states (`distinctBadgeBgCount == 6`) that do not collide with the primary CTA button or preview headers.
- **C2.4 (Platform Preview Fidelity & Impeccable Craft Floor):** Originally framed as matching platform fonts, displaying verified `syncloom-core` unit limits, making zero unverified claims, and violating zero Impeccable `craft-floor.md` bans.
Post-experiment / pre-challenge scope amendment (`2026-11-02`, [scope-amendment.md](scope-amendment.md) SHA256 `1716f730b9ed1bc6af89c22c3cf4a0386c48a445e65ebd3905fac68272f4f0d9`):
- **Amended C2.3 (Canonical State Truth Over Six Colors):** Six distinct badge colors are only a visual signal, not proof of truthful state semantics. `syncloom-core` has two separate dimensions: **Review State (`Piece.status`: `pending_review`, `approved`, `rejected`)** and **Delivery Outcome (`Piece.publish_status`: `contained`, `exported`, `posting`, `posted`, `refused`, `consent_required`, `rate_limited`, `unreachable`, `unknown`)**. Both dimensions must be shown separately with explicit words and recovery rules, preserving `outbox.rs:46-55` no-blind-retry behavior (`posting` and `unknown` are uncertain outcomes and must never be retried blindly or collapsed into `rejected`).
- **Amended C2.4 (Honest Local Previews):** Local `syncloom-core` rules do not independently verify current external platform limits, remote web fonts, fold positions, or remote feed layout. Previews must preserve the exact saved post text verbatim and be labeled explicitly as **approximate local previews** with conservative app fit checks and dated cost estimates (`2026-10-31`).

## 3. Unknown-resolution plan
- **U2.1:** What do the sampled Chrome 156 measurements of `B0` (Incumbent Sage), `P1` (Warm Editorial Atelier), `P2` (Precision Ink & Mineral Botanical), and `P3` (High-Chroma Cobalt Command) establish, and what remains unproven until the actual product screens are built? Resolution: bounded specimen pass (Section 6) and independent challenger audit (Section 5).
Research: N/A; local fit bounds are verified in `crates/syncloom-core/src/{channel.rs,x.rs,routing.rs,outbox.rs}` and Impeccable references are retained at `data/syncloom-text-ui-challenge/impeccable-source/`.

## 4. Evidence and options
### Claims

| ID | Claim | Status | Evidence |
| --- | --- | --- | --- |
| C1 | Incumbent `studio.css` (`B0`) declares `color-scheme: light` with zero dark-mode rules, sets base font-size to `15px`, uses `clamp(32px, 4vw, 52px)` for `h1`, uses `.eyebrow` kickers and `01 /` numbered markers, and styles all `.status` badges with a single green palette (`#eff4e9` bg, `#30583e` fg). | verified | [studio.css](../../../crates/syncloom-server/src/studio.css), 2026-11-02, lines 1-215; verified in `palette-experiment/metrics-light-1440.json` |
| C2 | `syncloom-core` defines conservative local fit checks per channel: LinkedIn `20..=3000` scalar chars, X `1..=280` conservative weighted units + dated micro-USD estimate (`2026-10-31`), Bluesky `1..=300` graphemes & `<= 3000` UTF-8 bytes, Threads `1..=500` UTF-8 bytes (text-only), Mastodon `1..=500` chars, Facebook Page `1..=63206` chars, Instagram `1..=2200` chars, Manual Export `1..=40000` chars; `Piece.routing` maps `En -> @camiloexperience` and `Es -> @camilojourney` as review targets, not connected OAuth accounts. | verified | [channel.rs](../../../crates/syncloom-core/src/channel.rs), 2026-11-02, lines 84-174; [routing.rs](../../../crates/syncloom-core/src/routing.rs), lines 13-20, 147-174 |
| C3 | `syncloom-core` tracks a 3-state `Piece.status` (`pending_review`, `approved`, `rejected`) and a separate 9-state `IntentStatus` (`contained`, `exported`, `posting`, `posted`, `refused`, `consent_required`, `rate_limited`, `unreachable`, `unknown`), where `allows_new_attempt()` is `false` for `posting`, `posted`, `exported`, and `unknown`. | verified | [piece.rs](../../../crates/syncloom-core/src/piece.rs), 2026-11-02, lines 8-27, 38-67; [outbox.rs](../../../crates/syncloom-core/src/outbox.rs), lines 8-55 |
| C4 | In the sampled Chrome 156 specimen (`metrics-dark-1440.json`), `P3` (`High-Chroma Cobalt Command`) rendered body prose at `14px` / `21px` and failed WCAG AA `4.5:1` on its dark-mode primary CTA (`#6366F1` on `#FFFFFF` = `4.47:1`). | verified | [studio.css](../../../crates/syncloom-server/src/studio.css), 2026-11-02, compared in `palette-experiment/metrics-dark-1440.json` (SHA256 `2bd3faf0aed5eb22985369984332fc2f06747df44d9ed8bd68bb75ea692e5a87`) |
| C5 | In the sampled Chrome 156 specimen, both `P1` (`Warm Editorial Atelier`) and `P2` (`Precision Ink & Mineral Botanical`) passed all sampled contrast pairs (`P1`: `17.49:1` L / `15.64:1` D prose, `7.31:1` L / `5.30:1` D CTA; `P2`: `16.81:1` L / `15.05:1` D prose, `8.77:1` L / `9.04:1` D CTA; badges `5.88-12.98:1`), with `P1` rendering `16.5px` serif draft prose (`587px` width) and `P2` rendering `16px` sans draft prose (`611px` width). | verified | [studio.css](../../../crates/syncloom-server/src/studio.css), 2026-11-02, compared in `palette-experiment/metrics-light-1440.json` and `metrics-dark-1440.json` |
| C6 | The static specimen experiment had four material limitations: (a) the PNGs embedded authored recommendation labels; (b) `comparison-light-390.png` and `comparison-dark-390.png` captured only `B0` and the top of `P1` (omitting `P2`/`P3` mobile visuals); (c) `metrics-dark-*.json` reported identical line-height (`26.88px` for P2, `28.875px` for P1) in light and dark, so dark leading compensation (`1.72` / `27.52px`) was not computed in the specimen; and (d) all three new specimens used Unicode glyph prefixes (`○`, `✓`, `▣`, `◫`, `●`, `×`), which conflict with Impeccable `craft-floor.md:40`'s caution against Unicode glyphs standing in for an icon system. | verified | [initial.md](../../syncloom-text-ui-challenge/initial.md), 2026-11-02, sections `Input framing and evidence asymmetry` and `Palette/type` |
| C7 | Neither `P1` nor `P2` has demonstrated every frozen pass mark (`C2.1`-`C2.4`) on actual built product pages, nor can any local system-font preview verify current external platform limits, remote web fonts, or device-dependent fold positions. | unverified | none: requires building the actual `syncloom-server` product pages in `syncloom-text-ui` and running full-page Light/Dark x `1440x900`/`390x844` checks |

### Assessment
Contradictions: Our initial draft overstated `P2` as an all-criteria experiment winner (`PASS` across `C2.1`-`C2.4`). As the challenger demonstrated (C6, C7), **no option demonstrated every frozen criterion in the specimen**:
- **B0 (Incumbent Sage):** Fails `C2.1` (`15px` prose < `16px` floor), `C2.2` (no dark mode), `C2.3` (1 badge style, 3 states only), and `C2.4` (`.eyebrow` kickers, `01 /` numbered markers, fluid `clamp()`).
- **P3 (High-Chroma Cobalt Command):** Fails `C2.1` (`14px` prose), `C2.2` (`4.47:1` dark CTA < `4.5:1`), and `C2.4` (decorative monospace headers).
- **P1 (Warm Editorial Atelier):** Passes sampled `C2.1` (`16.5px` prose) and sampled `C2.2` (`17.49:1` L / `15.64:1` D prose; `7.31:1` L / `5.30:1` D CTA). Impeccable `operate.md:13` ("one font family is often right") and `typeset.md:46` do **not** ban a serif draft editor, and the alleged orange/amber collision is an authored judgment rather than measured confusion. Remains a strong, viable alternative.
- **P2 (Precision Ink & Mineral Botanical):** Passes sampled `C2.1` (`16px` prose) and sampled `C2.2` (`16.81:1` L / `15.05:1` D prose; `8.77:1` L / `9.04:1` D CTA), and offers a calm, unified sans-serif editing/review voice that evolves `syncloom.v2`'s existing mineral-green studio identity. However, in the specimen: (a) mobile visuals for `P2` were not captured in the `390px` PNGs; (b) dark leading compensation (`27.52px`) was not active in the specimen metrics (`26.88px`); (c) `Posted` (`#14532D`/`#10B981`) and primary CTA (`#1B5442`/`#34D399`) share the botanical/mint hue family; and (d) Unicode symbol prefixes (`○`, `▣`, `◫`) must be replaced with explicit words + CSS geometric shapes per `craft-floor.md:40`.

## 5. Challenge
Applicability: consequential visual-system and state-representation choice; independent different-family challenge executed.
Challenger: OpenAI Codex (`PI_PROVIDER=openai-codex`, model `gpt-6.1-sol`, reasoning `xhigh`), trace `583631ab16b4845f28001b7e445f07fe`.
Commissioning input: `data/syncloom-text-ui-design/decisions/challenge-input.md` (SHA256 `7817abd8e303f4116b90317444b8f4d5a70a115d6267b7c54482e72de2c822df`), `decisions/frozen-pre-experiment.md` (SHA256 `fec3e3b027d05a7c56daac9a1f128033adae66d54dae01137f7e78f97c638481`), and `decisions/scope-amendment.md` (SHA256 `1716f730b9ed1bc6af89c22c3cf4a0386c48a445e65ebd3905fac68272f4f0d9`).
Evidence boundary: Canonical `main` at `c0584e87a808f457bd7b205da3009c485243d4e0`, retained Impeccable source at `data/syncloom-text-ui-challenge/impeccable-source/`, and saved specimen PNGs/JSONs.
Initial pick and defense (`data/syncloom-text-ui-challenge/initial.md`, SHA256 `bf962ca53fc2aa1504139447cf380539f0f8ca5f26e51136750c7fbfee902108`):
- Picked **P2 as a provisional product-UI direction, not a demonstrated experiment winner or an all-criteria pass**, while defending **P1** as genuinely competitive and noting that explicit two-axis state labels (`Piece.status` + `Piece.publish_status`) matter far more than six badge colors.
Agreement/disagreement and decision-owner resolution:
- **Provisional agreement on P2:** Both primary and challenger select **P2** as the provisional palette/type direction for `syncloom-text-ui` ( noting that challenger agreement is not independent visual corroboration because the specimen PNGs embedded recommendation labels).
- **Corrections accepted from challenger:**
  1. Recorded all four specimen limitations (embedded labels in PNGs, missing P2/P3 mobile visual renders in `390px` PNGs, unapplied dark-mode leading compensation in `metrics-dark-*.json`, and shared botanical/mint family between `Posted` badge and primary CTA) without rerunning the specimen.
  2. Separated **Review State (`Piece.status`: `pending_review`, `approved`, `rejected`)** and **Delivery Outcome (`Piece.publish_status`: `contained`, `exported`, `posting`, `posted`, `refused`, `consent_required`, `rate_limited`, `unreachable`, `unknown`)** into two distinct status displays, with a dedicated non-retryable caution badge/copy for `posting`/`unknown`.
  3. Changed `Posted` badge styling so it does not look like a solid primary CTA button (using a bordered emerald surface with a filled CSS dot and explicit non-interactive label `Posted · verified ID`, distinct from the solid `#1B5442`/`#34D399` action buttons).
  4. Replaced Unicode glyph prefixes (`○`, `✓`, `▣`, `◫`, `●`, `×`) with explicit text labels and CSS-drawn geometric indicators (`border-style` + CSS circle/square pseudo-element) per `craft-floor.md:40`.
  5. Labeled all platform previews explicitly as **approximate local previews** with conservative local fit checks and dated cost estimates (`2026-10-31`).
Strongest competing option/disconfirmation: **Option P1 (`Warm Editorial Atelier`)** remains ready if captain review prefers a warm stone parchment + serif draft-reading voice, or if any P2 token pair fails full-page contrast/distinguishability on the built product screens.
Recommendation revealed at: `2026-11-02` after `data/syncloom-text-ui-challenge/initial.md` (SHA256 `bf962ca53fc2aa1504139447cf380539f0f8ca5f26e51136750c7fbfee902108`) was durably saved (`008.msg`).
Objection and answer:
- *Challenger objections (`O2`, `O3` in `second-round-objections.md` and `decisions/challenge-response-2026-11-02.md`):*
  - `O2:` `P2` is not a proved all-criteria winner and `P1` is not empirically falsified: the specimen PNGs embedded recommendation text, the `390px` PNGs omitted `P2`/`P3`, dark leading (`27.52px`) was not active in `metrics-dark-*.json` (`26.88px`), `P2`'s primary CTA and original `Posted` badge shared green/mint families, and any revised token contrast numbers (`--badge-unknown-*`, bordered `--badge-posted-*`) are prospective targets rather than original experiment measurements.
  - `O3:` Action affordances on `/review/{piece_id}` must derive from the composition of both axes (`Piece.status` and serialized `Piece.publish_status` in `piece.rs:8-27,38-67`, `outbox.rs:46-55`, `studio.rs:924-940`), not a generic `Approved` row—specifically handling `"posting"` (serialized core value) and `"unknown"` (no blind retry), `"posted"` (no new send advertised), `"contained"`/`"exported"` (never remote success), and retryable failures (`"refused"`, `"consent_required"`, `"rate_limited"`, `"unreachable"`).
- *Answer (`decisions/challenge-response-2026-11-02.md`):* Accepted in full.
  - For `O2`, we distinguish the original reported Chrome 156 specimen measurements from prospective token contrast targets, drop all claims of all-criteria victory, remote platform font/layout parity, or empirical user-experience superiority over `P1`, and retain `P1` (`Warm Editorial Atelier`) as a competitive alternative. Final quality must be proven on the actual built `syncloom-server` product pages without rerunning static palette specimens.
  - For `O3`, `implementation-packet.md` specifies the composed `(Piece.status, Piece.publish_status)` action matrix together with the final challenger report's bounded semantic caveats (`data/syncloom-text-ui-challenge/report.md` SHA256 `3b148c7badae7a95d66068e1d40d68cdfd0ff1370b5fb3c2baf782b51823efa6`): (a) `Piece.publish_status` is a last-operation summary (`studio.rs:798-816`), so `"exported"` (`export:{target}` at `studio.rs:425-464`) means the export created local files only and does not prove no prior publish intent existed or block a separate `OPERATION_PUBLISH` check; (b) `"contained"` (`studio.rs:683-703, 763-793`) means the publish intent was saved locally with nothing sent by that intent (not solely that `SYNCLOOM_DELIVERY` is unset); (c) a persisted `"posting"` marker (`outbox.rs:16`, `studio.rs:929-935`) is an unconfirmed prior attempt converted to `"unknown"`, not proof of live in-progress execution, and both suppress/disable blind retry; (d) `Status::Approved` with `publish_status: None` is labeled `No dispatch recorded for this revision` (not `"Ready to publish"`, since approval does not verify account/credential/grant readiness); and (e) `GET /review/{id}` (`Studio::show`) returns `Piece` (`status` + `publish_status`), whereas full `PublishResponse` receipt fields (`post_id`, `post_url`, `attempts`, `reason`, `request_id`) are returned on `POST /review/{id}/publish` and must not be invented on `GET`.

## 6. Experiment
Protocol freeze: `2026-11-02T14:04:00Z` in [frozen-pre-experiment.md](frozen-pre-experiment.md) (SHA256 `fec3e3b027d05a7c56daac9a1f128033adae66d54dae01137f7e78f97c638481`).
Question/baseline/prior pass mark: Sampled Chrome 156 contrast, prose font-size/line-height/width, and horizontal overflow across `B0`, `P1`, `P2`, and `P3`.
Safety/time/cost cap/stop/rollback: Loopback static server on `127.0.0.1:63944`, single owned tab in Chrome 156, 1 pass, tab and server closed on exit.
Actual result and retained limitations (never rerun to hide defects):
- Retained files in `data/syncloom-text-ui-design/palette-experiment/`:
  - `metrics-light-1440.json` (`7abb7cd13827069d4def51ec7d331501f9b25cdca12891d7dc22bc01b1a93c41`)
  - `metrics-dark-1440.json` (`2bd3faf0aed5eb22985369984332fc2f06747df44d9ed8bd68bb75ea692e5a87`)
  - `metrics-light-390.json` (`2888bd2c7dc7e4d39f6c4bf0288cf39dac684cff13289a0bd80afec4b8a727c0`)
  - `metrics-dark-390.json` (`b76e3df49da53a6e539f0ed048afe3dfdf7764cae355d336e3e08bad17272527`)
  - `comparison-light-1440.png` (`f58b6f51a1268da01eaa366232afcf6b9ff0c2c2dbad38cbabadf515ecd1d9d2`)
  - `comparison-dark-1440.png` (`88b01908c8214dd9e023a5f346346586e315c69003e5eb07613aa8a7b7ee0498`)
  - `comparison-light-390.png` (`353ab3c3c16f77df8ce2c6eb6cfd30ba7c0f53f41b99b8618cd01a2c1d84e70e`)
  - `comparison-dark-390.png` (`da45324fe9ca9791e7d8f1886653e8842f57af5bf2e6bc8e0769d79e93b29b4f`)
- What the experiment established: `B0` (`15px`, no dark mode, 1 badge style) and `P3` (`14px`, `4.47:1` dark CTA) fail sampled criteria; `P1` and `P2` pass sampled contrast (`>= 5.3:1` CTA, `>= 7.6:1` secondary text, `>= 15.05:1` prose) and body size (`>= 16px`).
- What the experiment did **not** establish: complete all-criteria pass, unbiased visual comparison (PNGs contained recommendation text), `390px` visual rendering of `P2`/`P3` (cropped out of viewport), computed dark-mode leading compensation (`metrics-dark-*.json` stayed at `26.88px`), or two-axis state truth.

## 7. Decision
Choice and criterion-based reasons: **Select Option P2 (`Precision Ink & Mineral Botanical` Light/Dark palette with unified `16px` system Neo-Grotesque sans and tabular monospace) as a provisional product-UI direction**, with the challenger's semantic, iconographic, and preview-honesty corrections incorporated into `implementation-packet.md`.
Rejected alternatives:
- **B0 (Incumbent Sage):** Rejected for `15px` prose, lack of dark mode, single green status pill, and `.eyebrow` / `01 /` scaffold.
- **P3 (High-Chroma Cobalt Command):** Rejected for `14px` prose, `4.47:1` dark CTA contrast failure, and decorative monospace headings.
- **P1 (Warm Editorial Atelier):** Retained as the strongest competing option (`16.5px` serif draft prose, passing sampled contrast); deferred provisionally in favor of `P2`'s unified system-sans editing/preview voice and continuity with `syncloom.v2`'s mineral-botanical studio palette.
Human-owned questions: Captain visual preference after reviewing the actual built product screenshots in Light/Dark at `1440x900` and `390x844`.
Premises:
- **P2.1:** The actual built product screens (`GET /`, `GET /review/{id}`, `GET /review/{id}/edit`, `GET /review/{id}/render`, and shared error view) will achieve >= `4.5:1` normal-text contrast, computed dark-mode prose line-height `27.52px` (`1.72` at `16px`), zero horizontal overflow, and full-page visual captures at both `1440x900` and `390x844` in Light and Dark mode. Falsifying observation: any built product screen failing contrast, clipping controls, or failing Impeccable audit during `syncloom-text-ui`; check date `2026-11-16`.

### Reconsideration trigger

| Signal | Owner | Action |
| --- | --- | --- |
| Built product screenshots in `syncloom-text-ui` show contrast/distinguishability issues under `P2`, or captain review prefers `P1`'s warm parchment + serif reading surface | syncloom-v2-lab | Reopen `frontend/0008-text-studio-palette-and-typography` and switch token values in `studio.css` to `P1` (with neutral/slate CTA) or adjusted tokens |

Verification: Code 5.4.2 (`verify.py` / `findings.py`) and full-page Chrome 156 product captures + Impeccable critique/audit in `syncloom-text-ui`.

## 8. Outcome review
Owner/date: `syncloom-v2-lab` / `2026-11-16`
Resolvable predictions:
- **Pred-2.1 (by `2026-11-16`, source: `syncloom-text-ui` full-page Chrome 156 captures and computed-style checks across all actual product routes in Light/Dark x `1440x900`/`390x844`):** Every built product page will verify `>= 4.5:1` normal-text contrast, computed dark-mode prose line-height `27.52px`, `scrollWidth <= clientWidth`, zero truncated words/buttons, and separate Review Status (`Piece.status`) + Delivery Outcome (`Piece.publish_status` including `posting`/`unknown` no-blind-retry) rendering (confidence: 0.88, uncalibrated).
Batch review: Fleet coordinating owner; 2nd `Method: decide@1.3.1` record in `syncloom.v2`.
Outcome-blind process review: pending (`2026-11-16`).
Observed outcomes: pending until `2026-11-16`.
Follow-up/supersedes: supersedes none.
Implementation: to be linked from the `syncloom-text-ui` OpenSpec change (`openspec/changes/add-text-studio-frontend/`).
