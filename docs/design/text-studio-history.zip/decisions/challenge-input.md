# Independent Challenger Commissioning Packet (Conclusion-Free)

**Target Repository:** `syncloom.v2` at commit `c0584e87a808f457bd7b205da3009c485243d4e0`
**Method:** `decide@1.3.1`, source `baa7c65c88fa04eaa2d2167e78b24ff56e575e68`
**Checklist:** `1.0.0`, SHA256 `8c88c2c9c524d97552f67f30f6c4ba25589516b9dc18a51b09f7962688e5b056`
**Instructions for Challenger:**
1. Read the two questions, hard constraints, frozen acceptance criteria, real options, and authorized evidence below.
2. Without seeing the primary agent's recommendation, state your initial pick for **Decision 1 (Frontend Stack)** and **Decision 2 (Palette & Typography)**, defend each pick against the frozen criteria, and identify where each option fails, which assumptions lack transferable evidence, and what simpler procedure could work as well.

---

## Decision 1 Question: Frontend Rendering & Interaction Stack (`frontend/0007-text-studio-frontend-stack`)

Which frontend rendering and interaction stack should `syncloom.v2` use across its 6 browser studio pages (Studio Workspace & Post Ledger, Piece Review & Platform Previews, Edit Draft, Render Previews, Platform Connections & Delivery Boundaries, and Error/Recovery)?

### Options
- **Option S1:** Modularized zero-dependency Rust server-rendered HTML and CSS in `crates/syncloom-server/src/page/` (`mod.rs`, `home.rs`, `review.rs`, `previews.rs`, `connections.rs`) plus `studio.css`, using native HTML forms (`GET`/`POST`) and URL query parameters (`/?status=...&channel=...`), escaping via `syncloom_core::html::escape`.
- **Option S2:** Compile-time typed Rust template crate (`askama` or `maud`) in `crates/syncloom-server`, emitting script-free HTML over Axum routes.
- **Option S3:** Rust-to-WASM client/isomorphic UI framework (`Leptos` or `Dioxus` Web) compiled to `wasm32-unknown-unknown` with JS glue calling `/v1/*` JSON routes.
- **Option S4:** TypeScript/React SPA (`Next.js` or `Vite`) calling `/v1/*` JSON routes.

### Hard Constraints & Authorized Evidence
- **E1.1 (Language Rule):** Vision 1.2 (`docs/vision.md`) and ADR-0001 (`docs/decisions/0001-syncloom-v2-rebuild-decisions.md`): `"build it with rust all of it"`; operator studio is a browser page served by the Rust core (D1).
- **E1.2 (CSP & Session Boundary):** `crates/syncloom-server/src/boundary.rs:62-104` and `openspec/specs/studio-api/spec.md` enforce `Content-Security-Policy: default-src 'none'; script-src 'none'; style-src 'self'; img-src 'self'; frame-src 'self'; object-src 'none'; connect-src 'self'; form-action 'self'; base-uri 'none'`, exact `Host: 127.0.0.1:<port>`, exact `Origin`, and `csrf` hidden fields in `application/x-www-form-urlencoded` form POSTs. Main's ruling in `openspec/changes/polish-social-review/proposal.md` states: `"script-free - keep CSP script-src 'none' and the landed no-script rule."`
- **E1.3 (Offline Nix & Lockfile):** `Cargo.toml` and `Cargo.lock` hold 26 workspace dependencies (Axum 0.8, Tokio 1, Serde 1, etc.) and 0 third-party HTML template or WASM crates. `docs/development.md` requires hermetic builds and tests in the locked Fleet Nix Rust 1.99.1 profile without network fetches or `node_modules`.
- **E1.4 (Code Verify Complexity):** `crates/syncloom-server/src/page.rs` is currently 648 lines; `openspec/changes/polish-social-review/tasks.md` notes that Code Verify rejected page-renderer complexity growth until controls were extracted. `syncloom_core::html::escape` (`crates/syncloom-core/src/html.rs`) is the shared HTML escaping owner.

### Frozen Acceptance Criteria (Decision 1)
- **C1.1 (CSP & Boundary Compliance - Pass Mark: 100%):** Preserves `script-src 'none'`, exact `Host`/`Origin` checks, and CSRF form validation in `boundary.rs`.
- **C1.2 (Offline Nix & Hermetic Build - Pass Mark: 0 uncached crates / 0 external toolchains):** Compiles and passes `cargo fmt --check && cargo clippy --all-targets -- -D warnings && cargo test` using only the cached `Cargo.lock` and Nix Rust 1.99.1 toolchain.
- **C1.3 (Complete Operation & Endpoint Coverage - Pass Mark: 100% of loopback API capabilities reachable script-free):** Supports multi-channel thought drafting, queue filtering/pagination, draft text editing, status transitions (`approve`, `reject`, `reopen`), X dated cost consent, publish and dry-run, manual export (`reddit`/`tiktok`), visual rendering, and platform connection status/sign-in/refresh/sign-out without client-side scripts.
- **C1.4 (Single Owner per Rule & Maintainability - Pass Mark: 0 duplicated validation/escaping owners):** `syncloom-core::Studio` owns domain rules and `syncloom_core::html::escape` owns HTML escaping, with cohesive module structure passing Code Verify.

---

## Decision 2 Question: Visual Palette & Typography System (`frontend/0008-text-studio-palette-and-typography`)

Which visual color palette (Light and Dark themes) and typography system should `syncloom.v2` use across its 6 browser studio pages?

### Options
- **Option B0 (Incumbent Sage in `studio.css`):** Light-only (`#f6f7f2` canvas, `#ffffff` surface, `#172d2b` ink, `#586864` muted, `#215c49` green CTA), `15px` system sans body, `clamp(32px, 4vw, 52px)` `h1`, uppercase `.eyebrow` kickers, `01 /` numbered section markers, and a single green `.status` pill (`#eff4e9` bg / `#30583e` fg) for all statuses.
- **Option P1 (Warm Editorial Atelier):** Warm stone parchment `#F7F4EF` (Light) / obsidian `#121110` (Dark), elevated surface `#FFFFFF` / `#1C1917`, ink `#1C1917` / `#F5F2EB`, muted `#4E4740` / `#BFB8AE`, terracotta-orange primary CTA `#9A3412` on `#FFFFFF` (Light) / `#EA580C` on `#121110` (Dark); transitional serif (`"Iowan Old Style", "Charter", "Palatino", Georgia, serif`) at `16.5px` (`1.75` line-height) for draft prose, system sans (`15px`) for UI and platform previews, `ui-monospace` for hashes/counts, plus 6 semantic status badges.
- **Option P2 (Precision Ink & Mineral Botanical):** Warm mineral paper `#F5F6F3` (Light) / deep carbon-pine `#0D1312` (Dark), elevated surface `#FFFFFF` / `#141D1B`, second neutral layer `#EBEEE9` / `#1B2624`, ink `#11201E` / `#ECF1EE`, tinted secondary `#415450` / `#9FB0AC`, deep botanical pine primary CTA `#1B5442` on `#FFFFFF` (Light) / mint-emerald `#34D399` with `#091E16` ink (Dark); unified Neo-Grotesque system sans (`-apple-system, BlinkMacSystemFont, "SF Pro Text", "Segoe UI", system-ui, sans-serif`) at `16px` (`1rem`) body/draft prose floor (`1.68` line-height in light, `1.72` in dark, `60-66ch` measure) and fixed `rem` scale (`12px`, `14px`, `16px`, `18px`, `24px`), `ui-monospace` with `tabular-nums` for hashes/counts, and 6 semantic status badges (`Pending review` Amber, `Approved` Light-Emerald, `Contained` Indigo, `Exported` Cyan, `Posted` Solid-Forest/Mint, `Rejected`/`Alert` Crimson) with distinct symbol prefixes (`○`, `✓`, `▣`, `◫`, `●`, `×`).
- **Option P3 (High-Chroma Cobalt Command):** Cool slate `#F8FAFC` (Light) / deep navy `#090D16` (Dark), surface `#FFFFFF` / `#0F172A`, ink `#0F172A` / `#F8FAFC`, muted `#475569` / `#94A3B8`, electric indigo primary CTA `#4F46E5` on `#FFFFFF` (Light) / `#6366F1` on `#FFFFFF` (Dark); compact `14px` sans body prose (`1.5` line-height), `ui-monospace` section headers and metadata, and 6 semantic status badges.

### Authorized Evidence (Bounded Chrome 156 Experiment & Core Rules)
- **E2.1 (Measured Chrome 156 Metrics at `1440x900` and `390x844`, Light & Dark):**
  - **Light `1440x900` (`metrics-light-1440.json`):**
    - `B0`: `proseFontSizePx: "15px"`, `proseLineHeightPx: "27.75px"`, `proseWidthPx: 611`, `proseContrast: 14.52`, `mutedContrast: 5.87`, `ctaContrast: 7.8`, `secondaryContrast: 7.25`, `badgeDraftContrast: 7.25`, `badgeApprovedContrast: 7.25`, `badgeRejectedContrast: 7.25`, `distinctBadgeBgCount: 1`, `overflowX: false`.
    - `P1`: `proseFontSizePx: "16.5px"`, `proseLineHeightPx: "28.875px"`, `proseWidthPx: 587`, `proseContrast: 17.49`, `mutedContrast: 9.13`, `ctaContrast: 7.31`, `secondaryContrast: 14.83`, badges `8.14-12.98`, `distinctBadgeBgCount: 6`, `overflowX: false`.
    - `P2`: `proseFontSizePx: "16px"`, `proseLineHeightPx: "26.88px"`, `proseWidthPx: 611`, `proseContrast: 16.81`, `mutedContrast: 8.05`, `ctaContrast: 8.77`, `secondaryContrast: 14.36`, badges `8.14-12.98`, `distinctBadgeBgCount: 6`, `overflowX: false`.
    - `P3`: `proseFontSizePx: "14px"`, `proseLineHeightPx: "21px"`, `proseWidthPx: 611`, `proseContrast: 17.85`, `mutedContrast: 7.58`, `ctaContrast: 6.29`, `secondaryContrast: 16.3`, badges `8.14-12.98`, `distinctBadgeBgCount: 6`, `overflowX: false`.
  - **Dark `1440x900` (`metrics-dark-1440.json`):**
    - `B0`: unchanged from Light (no dark mode rules).
    - `P1`: `proseContrast: 15.64`, `mutedContrast: 8.9`, `ctaContrast: 5.3`, `secondaryContrast: 13.98`, badges `5.88-10.96`, `distinctBadgeBgCount: 6`, `overflowX: false`.
    - `P2`: `proseContrast: 15.05`, `mutedContrast: 7.6`, `ctaContrast: 9.04`, `secondaryContrast: 13.62`, badges `5.88-10.96`, `distinctBadgeBgCount: 6`, `overflowX: false`.
    - `P3`: `proseContrast: 17.06`, `mutedContrast: 6.96`, `ctaContrast: 4.47`, `secondaryContrast: 13.98`, badges `5.88-10.96`, `distinctBadgeBgCount: 6`, `overflowX: false`.
- **E2.2 (Verified Platform Rules in `crates/syncloom-core/src/{channel.rs,routing.rs}`):**
  - LinkedIn: `20..=3000` Unicode scalar values; X: `1..=280` conservative weighted units + dated cost estimate (`$0.015` plain / `$0.200` URL-like, `2026-10-31`); Bluesky: `1..=300` graphemes & `<= 3000` UTF-8 bytes; Threads: `1..=500` UTF-8 bytes (text-only); Mastodon: `1..=500` chars; Facebook Page: `1..=63206` chars; Instagram: `1..=2200` chars; Manual export: `1..=40000` chars.
  - Routing: `Language::En` -> `@camiloexperience`, `Language::Es` -> `@camilojourney`, plus `thesis` (`<= 200` chars), `visual_hook`, `products`.
- **E2.3 (Pinned Impeccable Guidance at `e89e3ada3e875a89ac2c5d33d11e65ebef6fe285`):**
  - `craft-floor.md`: body/placeholder text >= `4.5:1`, large text/controls >= `3:1`; body measure `65-75ch`; bans `.eyebrow` kickers above headings, bans `01 / 02 / 03` section numbers unless sequence carries required information, bans decorative monospace (`rule:skill-reflex-mono-as-technical`), bans ghost cards (`1px` border + wide soft shadow), card radii `12-16px`.
  - `operate.md` & `typeset.md`: `1rem` / `16px` web body floor; fixed `rem` scale (`1.125-1.2` ratio) instead of fluid `clamp()` headings; single well-tuned sans family for Operate/Read product surfaces; dark-mode compensation (`+line-height`, `+tracking`).

### Frozen Acceptance Criteria (Decision 2)
- **C2.1 (Structural & Typographic Integrity):** Body/draft prose font-size >= `16px`; desktop reading measure `45-75ch`; fixed `rem` scale; `scrollWidth <= clientWidth` at `1440x900` and `390x844`; works under `default-src 'none'; style-src 'self'`.
- **C2.2 (Accessibility & Contrast):** 100% of computed normal-text foreground/background pairs >= `4.5:1` and large-text/control/focus pairs >= `3.0:1` in BOTH Light and Dark modes, plus non-color symbol/shape cues on every status badge.
- **C2.3 (Semantic Clarity Across Lifecycle States):** All 6 lifecycle states (`Pending review`, `Approved`, `Contained`, `Exported`, `Posted`, `Rejected`/`Failed`/`Unknown`) have distinct tokens (`distinctBadgeBgCount == 6`) and do not collide with the primary CTA button or platform preview headers.
- **C2.4 (Platform Preview Fidelity & Impeccable Craft Floor):** Previews for LinkedIn, X, Bluesky, and Threads match the Neo-Grotesque sans family used on those platforms, display exact verified `syncloom-core` unit limits and `ThoughtContract` routing, make zero unverified platform layout claims, and violate zero Impeccable `craft-floor.md` bans.
