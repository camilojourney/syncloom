# Primary Author Answers to Second-Round Challenger Objections (O1-O4)

**Date:** `2026-11-02 UTC`
**Responds to:** `data/syncloom-text-ui-challenge/second-round-objections.md` (and `initial.md` SHA256 `bf962ca53fc2aa1504139447cf380539f0f8ca5f26e51136750c7fbfee902108`)
**Purpose:** Short numbered answers (`O1`-`O4`) and acceptance of the two concrete packet corrections for verbatim inclusion in the decision records and challenge report.

---

### O1. Escaping guarantee in S1 vs S2

We accept the objection without qualification: because `String` and `&str` implement `std::fmt::Display`, a voluntary `Escaped<'a>` `Display` wrapper does **not** provide a compile-time guarantee against raw interpolation in `format!`. We retract that claim.

Our actual, smallest safety argument for **Option S1** across the 4-route text-first surface is:
1. **Single Escaping Owner:** All dynamic text passes through `syncloom_core::html::escape` (`crates/syncloom-core/src/html.rs`).
2. **Small, Auditable Render Functions:** Keeping the browser surface to the 4 existing route families (`home`, `review`, `edit`, and preserved `render` + shared `error`) bounds the number of interpolation sites so every `format!` call in `crates/syncloom-server/src/page/` is directly inspectable in code review.
3. **Inert-Output Regression Tests:** `crates/syncloom-server/tests/review_screen.rs` must assert that adversarial payloads containing `<`, `>`, `&`, `"`, and `'` across thought text, draft text, slide text, and routing fields render strictly as inert entity-escaped text on every page.
4. **No Home-Grown Template Framework & Explicit S2 Trigger:** We will not build a custom type/template wrapper to defend zero dependencies. If `S1` cannot keep dynamic HTML output auditable with plain functions + `syncloom_core::html::escape` + regression tests, **Option S2 (`maud` or `askama`)** wins under the amended `C1.4` reading.

---

### O2. P2 is a provisional direction, not a proved all-criteria winner; P1 remains competitive

We accept the objection and distinguish the original reported Chrome 156 specimen numbers from unsupported claims:
1. **What the specimen measured:** Only sampled foreground/background contrast ratios, font sizes, line heights, and pixel widths on a static 4-option HTML specimen (`palette-experiment/metrics-{light,dark}-{1440,390}.json`), where `B0` (`15px` prose, no dark mode, 1 badge style) and `P3` (`14px` prose, `4.47:1` dark CTA) failed sampled floors while both `P1` and `P2` passed sampled contrast (`>= 5.30:1` CTA, `>= 7.60:1` secondary text, `>= 15.05:1` prose).
2. **What the specimen did NOT establish:**
   - It did **not** establish an all-criteria pass for `P2`, exact remote platform font/layout/fold parity, `ch` measure, complete focus/hover/error/disabled contrast, or empirical reading/task superiority over `P1`.
   - The saved PNGs (`comparison-*.png`) embedded authored pro-`P2` / anti-`P1`/`P3` conclusions, and the `390x844` PNGs never visually captured `P2` or `P3`.
   - Both light and dark specimen metrics recorded `P2` line-height as `26.88px` (and `P1` as `28.875px`), so the intended `1.72` (`27.52px`) dark-mode leading compensation was not active in the specimen.
   - `P2`'s primary CTA (`#1B5442` / `#34D399`) and original `Posted` badge (`#14532D` / `#10B981`) shared green/mint hue families, so hue-family overlap cannot be used to disqualify `P1`'s terracotta CTA and amber draft badge.
   - Any revised token contrast ratios introduced after the specimen (such as `--badge-unknown-*` and the bordered `--badge-posted-*` token) are **prospective targets**, not original measured experiment results.
3. **Status of P2 and P1:** **Option P2** is adopted strictly as a **provisional product-UI direction** for its calm, unified system-sans editing/review voice, while **Option P1 (`Warm Editorial Atelier`)** is retained as a genuinely competitive alternative (`16.5px` serif draft prose, passing sampled contrast, sans previews). Final visual and accessibility verification will be run on the **actual built `syncloom-server` product pages** in `syncloom-text-ui`, without rerunning static palette specimens.

---

### O3. Composed Review (`Piece.status`) + Outbox (`Piece.publish_status`) action rules

We confirm that all action affordances on `GET /review/{piece_id}` derive from the **composition of both state axes (`Piece.status` and `Piece.publish_status`)** and `syncloom-core` invariants (`piece.rs:8-27,38-67`, `outbox.rs:46-55`, `studio.rs:924-940`). A generic `Status::Approved` rule never overrides outbox state:

| `Piece.status` (Review Axis) | `Piece.publish_status` (Serialized Outbox Axis) | UI State Labels (Review Badge + Delivery Badge) | Composed Action & Retry Rules on `/review/{piece_id}` |
| --- | --- | --- | --- |
| `pending_review` | `None` (or cleared on edit) | `Review: Pending review` · `Delivery: Not yet dispatched` | `Approve exact revision` enabled (unless `visual.is_some()` and `assets.is_none()`); `Publish` disabled (`approval_required`). |
| `rejected` | `None` | `Review: Rejected` · `Delivery: Not dispatched` | `Approve` and `Publish` disabled; recovery is `Edit draft` (`/review/{id}/edit`) to create a new revision. |
| `approved` | `None` | `Review: Approved` · `Delivery: Ready to publish` | For `Channel::X`, requires `Accept estimated cost` (`POST /review/{id}/accept-cost`) for the current `(revision, total_micro_usd, pricing_as_of)`; then `Publish` enabled. |
| `approved` | `Some("contained")` | `Review: Approved` · `Delivery: Contained locally (not sent)` | Explicitly states **zero network requests were sent** (`SYNCLOOM_DELIVERY` does not grant this platform). `allows_new_attempt() == true`, so `Publish` remains available if the operator runs with delivery granted. |
| `approved` | `Some("refused" \| "consent_required" \| "rate_limited" \| "unreachable")` | `Review: Approved` · `Delivery: Not posted ({status})` | Explicitly states **no remote post was created** and shows cause-specific recovery guidance (complete platform sign-in, wait for rate limit, check network, or edit draft). `allows_new_attempt() == true`. |
| `approved` | `Some("posting" \| "unknown")` | `Review: Approved` · `Delivery: Publishing in progress ("posting")` or `Delivery: Outcome unknown ("unknown") - do not retry blindly` | Core serializes `"posting"` and `"unknown"` with `allows_new_attempt() == false`. **Suppress/disable retry/publish controls for this revision** and display a prominent warning to check the remote platform account before taking action. |
| `approved` | `Some("posted")` | `Review: Approved` · `Delivery: Posted (verified post ID)` | Core `allows_new_attempt() == false`. Display the verified `post_id` / `post_url` receipt; **do not advertise `Publish` as a new send**. |
| `approved` | `Some("exported")` | `Review: Approved` · `Delivery: Exported local bundle (not posted)` | Core `allows_new_attempt() == false`. States that local files were written for manual handoff, never posted remotely. |

Non-color cues use these explicit state words plus consistent CSS-authored geometry (`border-style` and CSS `::before` dot/ring/bar shapes), without decorative Unicode glyph icons (`craft-floor.md:40`).

---

### O4. Smallest correct text surface and deterministic form/pagination semantics

We confirm that the implementation handoff chooses the **smallest correct existing text surface** and specifies deterministic server semantics rather than inventing unbacked query filters or new route families:
1. **No invented `/?status=...&channel=...` query filters:** `GET /` keeps the existing `Cursor { after: Option<String> }` (`deny_unknown_fields`, `page.rs:110-145`) backed by `Studio::list` (`studio.rs:556`, up to 20 pieces per page + `next_after`). We do **not** filter a 20-item page slice in template code.
2. **Deterministic `POST /actions/thought` form parsing (`page.rs` + `boundary.rs`):**
   - `boundary.rs` continues to enforce **exactly one** non-empty `csrf` field matching the session token (rejecting missing, wrong, or duplicate `csrf` fields with `403 session_required`).
   - `POST /actions/thought` parses the `application/x-www-form-urlencoded` body sequentially (`url::form_urlencoded::parse`):
     - Requires **exactly one** `text` field (duplicate or missing `text` field -> `400 invalid_request`).
     - Collects all `channels` field values in submission order into `Vec<String>` (never using a last-value-wins map).
     - In the HTML form on `GET /`, the `linkedin_text` checkbox is `checked` by default. If a request submits zero `channels` fields, or duplicate/unknown channels, the collected `Vec<String>` is passed to `Studio::create_thought` (`studio.rs:286-308`), which remains the single owner of channel-list validation (`400 invalid_request` on empty or duplicate channels, `422 unsupported_channel` on unknown channels, `422 thought_too_short` on `< 8` non-space chars).
     - On success (`ThoughtResponse`), redirects (`303 See Other`) to `/review/{first_piece_id}`, where sibling pieces sharing `piece.group_id` (when multiple channels were selected) are linked in the review header.
3. **Authoritative API matrix & excluded scope:** The API worker's `endpoint-matrix.md` (`syncloom-api-e2e`) is authoritative for `/v1/*` routes; `"none"` is the valid browser consumer for JSON/CLI routes. New credential/OAuth forms, `/connections` auth-boundary changes, and new image/carousel workflows remain excluded, while existing `/review/{id}/render` and `/v1/pieces/{id}/assets/*` routes remain preserved and compatibly styled.

---

### Acceptance of the Two Concrete Prospective Packet Corrections

1. **No double `@` on `Piece.routing` handles & honest legacy fallback:** `crates/syncloom-core/src/routing.rs:156-160` already includes the `@` prefix in `contract.destination.handle` (`"@camiloexperience"` and `"@camilojourney"`). `implementation-packet.md` is updated to render `{escape(&contract.destination.handle)}` once (never `@{...}`) and, when `piece.routing` is `None` on legacy pieces, to render `Suggested review target: not recorded` (never an invented `Founder account`).
2. **Case-consistent `--accent-tint` CSS token:** `implementation-packet.md` is updated so both the light-theme `:root` block and the `@media (prefers-color-scheme: dark)` `:root` block define lowercase `--accent-tint` (`#E6F0EC` in light, `#132A23` in dark), verified by computed-style checks in `syncloom-text-ui`.
