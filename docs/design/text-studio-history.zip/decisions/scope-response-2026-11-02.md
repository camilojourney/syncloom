# Dated Scope & Criteria Amendment Response (Post-Experiment, Pre-Challenger Reveal)

**Date:** `2026-11-02 UTC`
**Responds to:** `decisions/scope-amendment.md` and steering message `006.msg` (Main1304, Main1312, Main1327)
**Custody Note:** The original pre-experiment freeze (`decisions/frozen-pre-experiment.md`), decision drafts (`0007`, `0008`), challenger packet (`decisions/challenge-input.md`), recommendation packet (`decisions/recommendation.md`), and Chrome 156 experiment receipts (`palette-experiment/*`) are preserved byte-for-byte unchanged while the independent Codex-family challenger runs its blind initial assessment.

---

## 1. Re-Assessment of Decision 1 (`0007-text-studio-frontend-stack`) Under Original vs Amended Criteria

### 1.1 Removing the Artificial "Zero New Dependencies" Filter on C1.2
- **Original Framing (`C1.2`):** Treated `0 uncached crates added to Cargo.lock` as a hard pass/fail gate, which automatically rejected **Option S2 (compile-time typed Rust HTML templates such as `askama` or `maud`)** before comparing its engineering merits against **Option S1 (zero-dependency `format!` view functions in `crates/syncloom-server/src/page/` using `syncloom_core::html::escape`)**.
- **Amended Reading (`scope-amendment.md` Item 1):** `CSP script-src 'none'`, revision-bound approval, and containment are hard boundaries, whereas adding a vetted Rust crate via an online Nix lockfile update is allowed when justified by quality, simplicity, robustness, and long-term maintainability (`AGENTS.md`).
- **Side-by-Side Comparison of S1 vs S2 Under the Amended Reading:**

| Dimension | Option S1: Modularized `syncloom-server` View Functions + `syncloom_core::html::escape` | Option S2: Compile-Time Typed Rust Template Crate (`maud` or `askama`) |
| --- | --- | --- |
| **CSP (`script-src 'none'`), CSRF, & Containment (`C1.1`)** | **PASS** (pure server-rendered HTML + `/studio.css`). | **PASS** (pure server-rendered HTML + `/studio.css`). |
| **Escaping & XSS Safety** | Manual call to `syncloom_core::html::escape(&val)` at each interpolation site. Risk: omitting `escape()` on a new dynamic string compiles without error unless caught by review or tests. Mitigation: wrap dynamic text in a tiny local `Escaped<'a>(&'a str)` `Display` newtype inside `page/` so raw `String`/`&str` is not interpolated directly into HTML builders. | Automatic HTML escaping by default in `askama` templates or `maud::html!` macro (unescaped markup requires explicit `|safe` or `PreEscaped`). |
| **Single Owner per Rule (`code` Skill Rule 3)** | **PASS:** Reuses the existing `syncloom_core::html::escape` owner (`crates/syncloom-core/src/html.rs`) shared with `visual.rs`. | Introduces a second HTML-escaping implementation in the template crate unless `visual.rs` is also migrated or `Kept:` is recorded in `design.md`. |
| **Hermetic Build & Footprint** | Zero Cargo dependency or proc-macro changes; compiles immediately under the locked Fleet Shared Kit 1.0.2 profile (`docs/development.md`). | Requires adding `askama` or `maud` to `Cargo.toml` and updating `Cargo.lock` (plus `#[expect]` review if macro expansion triggers workspace clippy lints in `Cargo.toml`). |
| **Scope Proportional to 4 Existing Screen Surfaces** | With the amended 4-screen text-first scope (`GET /`, `GET /review/{id}`, `GET /review/{id}/edit`, `GET /review/{id}/render` + `page::error`), the total HTML surface is ~250-300 lines of template markup across 4 functions. | Best suited when template count grows large; for 4 existing routes, migrating all existing `page.rs` templates to a proc-macro DSL adds churn to unchanged render/edit markup. |

- **Amended Conclusion on Stack (`0007`):**
  - Options **S3 (WASM)** and **S4 (JS SPA)** still fail the hard `script-src 'none'` CSP boundary (`C1.1`).
  - Between **S1** and **S2**, **S1** remains the simplest direct path for the 4-screen text-first scope (`AGENTS.md`: *"start with the simplest direct end-to-end path"*), **provided** `page.rs` uses a small typed helper (or `syncloom_core::html::escape` wrapper) so dynamic piece fields cannot bypass escaping. If the challenger or supervisor prefers compile-time auto-escaping via `maud`/`askama` (`S2`), that is a valid engineering trade-off once `Cargo.lock` is refreshed.

---

## 2. Re-Assessment of Decision 2 (`0008-text-studio-palette-and-typography`) Under Original vs Amended Criteria

### 2.1 Canonical Lifecycle Semantics (`scope-amendment.md` Item 2)
The original `C2.3` measured `distinctBadgeBgCount == 6` across 6 badge classes. As `scope-amendment.md` Item 2 points out, **six distinct colors are only a structural signal, not proof of truthful state semantics**. Specifically, `syncloom-core` has two orthogonal state axes on a `Piece` (`crates/syncloom-core/src/piece.rs`, `crates/syncloom-core/src/outbox.rs`):

1. **Axis A - Human Review State (`Piece.status: Status`):**
   - `pending_review` (`Status::PendingReview`): Unapproved draft; cannot be published or exported.
   - `approved` (`Status::Approved`, with `review_decision_id: Some("review-...")`): Human approved this exact `revision` SHA-256 (and asset hashes if `visual.is_some()`). Editing text or slides immediately resets `status` to `pending_review` and clears `review_decision_id` and `publish_status`.
   - `rejected` (`Status::Rejected`): Human rejected this draft; cannot be published (`can_move_to` allows only `Rejected -> PendingReview` or editing text).
2. **Axis B - Dispatch Outbox Outcome (`Piece.publish_status: Option<String>` from `IntentStatus`):**
   - `None`: No publish or export intent recorded for the current `revision`.
   - `"contained"` (`IntentStatus::Contained`, `allows_new_attempt() == true`): Intent reserved locally in the outbox because `SYNCLOOM_DELIVERY` does not grant this platform (or LinkedIn visual); **zero network requests were sent and nothing was posted**.
   - `"exported"` (`IntentStatus::Exported`, `allows_new_attempt() == false`): Local manual handoff bundle (`text.txt`, `notes.md`, `manifest.json`) written under `SYNCLOOM_DATA_DIR/exports/`; **never a remote post**.
   - `"posted"` (`IntentStatus::Posted`, `allows_new_attempt() == false`): Remote platform confirmed creation and returned a verified `post_id` (and `post_url`). **Never sent again on repeat publish.**
   - `"posting"` / `"unknown"` (`IntentStatus::Posting` / `IntentStatus::Unknown`, `allows_new_attempt() == false`): A network attempt started or timed out/returned an unreadable response, so the remote post may or may not exist. **Never retried blindly** (`Studio::publish` returns `unknown` with zero new network requests). The UI must label this state as **Uncertain delivery - check the platform account before taking action** (distinct from a retryable refusal!).
   - `"refused"` / `"consent_required"` / `"rate_limited"` / `"unreachable"` (`allows_new_attempt() == true`): Definite pre-post or transport failure where no post was created; safe to retry once the cause (sign-in consent, rate limit window, network, or content rule) is resolved.

**Required Semantic Refinement in `P2`:**
Instead of collapsing `rejected`, `refused`, and `unknown`/`posting` into one generic red badge, the UI must render **Review Status (`Piece.status`)** and **Delivery Outcome (`Piece.publish_status`)** as separate, explicit labels with distinct copy and affordances:

| State Category | Values | Visual Token Pair (Light / Dark) | Non-Color Cue & Required Truthful Copy | Retry / Action Rule |
| --- | --- | --- | --- | --- |
| **Review: Pending** | `Status::PendingReview` | `--badge-draft-*` (Amber: `#FEF3C7`/`#78350F` L, `#2E210B`/`#FCD34D` D) | `○ Pending review` | `Approve exact revision` enabled (if `visual.is_none()` or `assets.is_some()`); `Publish` disabled. |
| **Review: Approved** | `Status::Approved` | `--badge-approved-*` (Emerald: `#DCFCE7`/`#14532D` L, `#0D2B1D`/`#86EFAC` D) | `✓ Approved revision` | `Approve` disabled; `Publish` enabled (after X cost consent if `Channel::X`). |
| **Review: Rejected** | `Status::Rejected` | `--badge-neutral-muted-*` (Slate: `#E2E8F0`/`#1E293B` L, `#1E293B`/`#CBD5E1` D) | `× Rejected draft` | `Approve` and `Publish` disabled; recovery is `Edit draft` to create a new revision. |
| **Outbox: Contained** | `publish_status = "contained"` | `--badge-contained-*` (Indigo: `#E0E7FF`/`#1E1B4B` L, `#191E38`/`#C7D2FE` D) | `▣ Contained locally (not sent)` | Explicitly states 0 network attempts were made (`SYNCLOOM_DELIVERY` unset for platform). |
| **Outbox: Exported** | `publish_status = "exported"` | `--badge-exported-*` (Cyan: `#CFFAFE`/`#164E63` L, `#0E2933`/`#67E8F9` D) | `◫ Exported local bundle (not posted)` | Explicitly states files were written locally for manual handoff, never posted. |
| **Outbox: Posted** | `publish_status = "posted"` | `--badge-posted-*` (Solid Forest/Mint: `#14532D`/`#FFFFFF` L, `#10B981`/`#052E16` D) | `● Posted (verified post ID)` | Displays `post_id` and `post_url`; repeat publish returns the same receipt without re-sending. |
| **Outbox: Uncertain (`posting` / `unknown`)** | `publish_status = "posting" \| "unknown"` | `--badge-unknown-*` (Deep Violet-Magenta Caution: `#FAE8FF`/`#701A75` L [8.9:1], `#3B0764`/`#F5D0FE` D [10.3:1]) | `? Outcome unknown - do not retry blindly` | **Never retried blindly** (`allows_new_attempt() == false`); instructs founder to check the platform feed before acting. |
| **Outbox: Retryable Failure** | `publish_status = "refused" \| "consent_required" \| "rate_limited" \| "unreachable"` | `--badge-failed-*` (Crimson: `#FEE2E2`/`#7F1D1D` L, `#311316`/`#FCA5A5` D) | `! Delivery failed ({status}) - not posted` | Names the exact core outcome (`refused`, `consent_required`, `rate_limited`, `unreachable`); allows retry after resolving cause. |

### 2.2 Honest Local Text Previews (`scope-amendment.md` Item 3)
- Every text preview card on `GET /review/{piece_id}` is labeled:
  - **`Approximate local preview · {Channel::display_name}`**
  - Displays the **complete, untruncated `piece.text`** (`white-space: pre-wrap`) with no invented "...see more" fold cutoff.
  - Labels the unit counter as **`Conservative local fit check: {fit.char_count} / {fit.max_chars} {count_unit()} ({fit.verdict})`** (plus `<= 3,000 UTF-8 bytes` for Bluesky), noting that `syncloom-core` uses conservative local bounds that do not claim to verify live remote platform rules or remote font rendering.
  - Labels `Piece.routing` (`@camiloexperience` EN / `@camilojourney` ES) as **`Suggested review target (from source language)`**, never as a connected OAuth account.
  - For `Channel::X`, displays the `CostEstimate` with its explicit `pricing_as_of` date (`2026-10-31`) and label **`Dated local estimate, not an actual charge`**.

---

## 3. Amended Screen Inventory & Endpoint Table (Scoped to Text-First Studio)

Per `scope-amendment.md` Items 1 and 4:
1. **No new credential-entry or OAuth connection pages (`GET /connections`, `POST /connections/*`) are added in this text-first slice.** `boundary::is_page_path` (`crates/syncloom-server/src/boundary.rs:80-82`) remains untouched (`path == "/" || path.starts_with("/review/") || path.starts_with("/actions/")`).
2. **No new image/carousel workflow is added.** The existing `GET /review/{piece_id}/render` page and asset routes (`GET /v1/pieces/{piece_id}/assets/*`) are preserved and inherit the updated `studio.css` tokens so they remain unbroken and accessible in Light and Dark modes.
3. **Actual Screen Inventory (4 Route Surfaces = 16 Browser Captures across Light/Dark x 1440/390, plus Error State = 20 Captures total):**
   - **Screen 1 (`GET /`, `POST /actions/thought`):** Studio Workspace - thought composer (supporting channel selection from `Channel` table via `Studio::create_thought`) + saved pieces ledger (`Studio::list`) showing distinct Review Status (`pending_review`, `approved`, `rejected`) and Outbox Outcome (`contained`, `exported`, `posted`, `unknown`, `refused`, `consent_required`, `rate_limited`, `unreachable`) badges, `Piece.routing` language/handle target, and pagination.
   - **Screen 2 (`GET /review/{piece_id}`, `POST /review/{piece_id}/{approve|accept-cost|publish}`):** Piece Review & Approximate Local Text Preview - source thought + `ThoughtContract` (`thesis`, `visual_hook`, `products`, `destination`), saved draft with full `revision` SHA-256 and conservative `fit` counter, approximate local platform text preview (`LinkedIn`, `X`, `Bluesky`, `Threads`, `Mastodon`, `Facebook`, `Instagram`, `Manual export`), revision-bound approval, X dated cost consent, and explicit publish with truthful `PublishResponse` receipt. (Existing rendered assets appear only when `piece.assets.is_some()`.)
   - **Screen 3 (`GET /review/{piece_id}/edit`, `POST /review/{piece_id}/edit`):** Edit Draft - isolated text editor with channel bounds, zero approve/publish controls, voiding approval on save.
   - **Screen 4 (`GET /review/{piece_id}/render`, `POST /review/{piece_id}/render`, plus `page::error`):** Existing Render Previews screen and Error Recovery page styled with the unified `P2` Light/Dark token system, with zero truncated words or buttons.
4. **Corrected Authoritative Endpoint-to-Consumer Table:**
   - **Browser HTML Routes (call `syncloom_core::Studio` directly in Rust; not JSON API consumers):**
     - `GET /` -> `Studio::list`
     - `POST /actions/thought` -> `Studio::create_thought`
     - `GET /review/{piece_id}` -> `Studio::show`
     - `GET /review/{piece_id}/edit` -> `Studio::show`
     - `POST /review/{piece_id}/edit` -> `Studio::review` (`text`)
     - `GET /review/{piece_id}/render` -> `Studio::show`
     - `POST /review/{piece_id}/render` -> `Studio::render`
     - `POST /review/{piece_id}/approve` -> `Studio::review` (`Status::Approved`)
     - `POST /review/{piece_id}/accept-cost` -> `CostConsents::accept` (`Studio::show`)
     - `POST /review/{piece_id}/publish` -> `Studio::publish`
     - `GET /studio.css` -> stylesheet served to all browser HTML routes
   - **Loopback JSON / Byte API Routes (authoritative executed API coverage owned by `syncloom-api-e2e` `endpoint-matrix.md`):**
     - `GET /v1/pieces/{piece_id}/assets/{image|carousel|slides/{index}}` -> Consumed by browser `<img>` and `<iframe>` tags on `GET /review/{piece_id}` when `piece.assets.is_some()`, and by CLI/API callers.
     - `GET /v1/session`, `GET /v1/health`, `GET /v1/pieces`, `POST /v1/thoughts`, `GET /v1/pieces/{piece_id}`, `PATCH /v1/pieces/{piece_id}`, `POST /v1/pieces/{piece_id}/publish`, `POST /v1/pieces/{piece_id}/export`, `POST /v1/pieces/{piece_id}/render`, `POST /v1/{linkedin|mastodon|meta|x|threads}/sign-in`, `GET /v1/{linkedin|mastodon|meta|x}/sign-in`, `POST /v1/bluesky/sign-in`, `POST /v1/threads/complete`, `GET /v1/{platform}/connection`, `DELETE /v1/{platform}/connection`, `POST /v1/{bluesky|x|threads}/refresh` -> **Browser page consumer: none** (consumed by `syncloom-cli` and HTTP JSON API clients; browser studio uses the direct Rust `Studio` HTML form adapters above).
5. **OpenSpec Telemetry Rule (Main1327):**
   - Every `openspec` command in `syncloom-text-ui` must be invoked with `OPENSPEC_TELEMETRY=0 DO_NOT_TRACK=1` (e.g. `OPENSPEC_TELEMETRY=0 DO_NOT_TRACK=1 openspec validate --all --strict --no-interactive`), while keeping local Langfuse OpenTelemetry active.

---

## 4. Dated Post-Reveal Response to Blind Challenger (`2026-11-02 UTC`, per `008.msg`)

**Challenger Record Read:** `data/syncloom-text-ui-challenge/initial.md` (SHA256 `bf962ca53fc2aa1504139447cf380539f0f8ca5f26e51136750c7fbfee902108`; `openai-codex/gpt-6.1-sol`, trace `583631ab16b4845f28001b7e445f07fe`).
**Preserved Unchanged:** `decisions/frozen-pre-experiment.md` (`fec3e3b0...`), `decisions/challenge-input.md` (`7817abd8...`), `decisions/recommendation.md` (`e313c4e3...`), `decisions/scope-amendment.md` (`1716f730...`), and `palette-experiment/*`.

### 4.1 Resolution of Challenger Findings

1. **Decision 1 (`0007`, Stack - S1 vs S2):**
   - Both primary and challenger selected **S1** (existing small Rust/Axum SSR surface in `crates/syncloom-server/src/page/` reusing `Studio` and `syncloom_core::html::escape`).
   - We adopt the challenger's correction in full: **S1 is selected because the existing transport, CSRF verification, and single-owner escaping architecture already fit the 4-screen text-first surface under one trust boundary, NOT because of an eternal "no new crates" rule.** `docs/development.md:46,84-102,122` allows adding reviewed, locked dependencies, and **S2 (`askama`/`maud`)** remains a genuine alternative if manual escaping or string templates prove fragile during implementation.
   - We also corrected the exact repository counts in `0007`: `page.rs` is `647` newline-terminated lines (`wc -l`), `Cargo.toml` has `32` workspace dependency entries (`30` external), and the canonical toolchain in `docs/development.md` is Rust `1.99.1`.
   - We removed fake `/?status=...&channel=...` query-filter claims that are not currently backed by `Studio::list` (`studio.rs:556`) or `page.rs:110-145`.
2. **Decision 2 (`0008`, Palette/Type - P2 Provisional vs P1):**
   - Both primary and challenger selected **P2 (`Precision Ink & Mineral Botanical`) as a provisional product-UI direction, NOT an all-criteria experiment winner or proof of exact remote platform/font fidelity**, with **P1 (`Warm Editorial Atelier`)** retained as a strong competing option.
   - Rather than rerunning the static specimen to chase favorable numbers, we record the four real limitations identified by the challenger:
     - **Embedded recommendations in specimen PNGs:** `comparison-{light,dark}-{1440,390}.png` contained authored conclusion labels inside the cards, so challenger convergence on P2 is not independent visual corroboration.
     - **Missing mobile visual renders for P2/P3:** `comparison-light-390.png` and `comparison-dark-390.png` captured only `B0` and the top of `P1` (not `P2` or `P3`), and desktop captures clipped lower controls.
     - **Unverified dark leading compensation:** `metrics-dark-1440.json` and `metrics-dark-390.json` reported `26.88px` line-height for P2 (and `28.875px` for P1), identical to light mode, because the specimen toggled `.dark` without dark-mode line-height rules. In `implementation-packet.md`, `studio.css` sets `--prose-leading: 1.72` (`27.52px` at `16px`) and `--prose-tracking: 0.005em` inside `@media (prefers-color-scheme: dark)` and verifies it on the built product pages.
     - **Badge count vs state truth & CTA hue separation:** Six badge backgrounds do not prove state truth, and P2's solid green `Posted` badge (`#14532D`/`#10B981`) shared the botanical/mint family of the primary CTA (`#1B5442`/`#34D399`). In `implementation-packet.md`, `Posted` uses a non-button bordered surface (`#E6F4EA`/`#062E22` bg with `2px solid` border and a CSS-drawn filled circle indicator) so it never resembles an interactive primary CTA button, and **Review State (`Piece.status`)** and **Delivery Outcome (`Piece.publish_status`, including `posting`/`unknown` no-blind-retry)** are rendered as two separate status dimensions.
     - **No decorative Unicode icon glyphs (`craft-floor.md:40`):** Removed Unicode symbol prefixes (`○`, `✓`, `▣`, `◫`, `●`, `×`, `↗`, `←`) from the badge and button specification in favor of explicit text labels and CSS geometric indicators (`::before` dot/ring + border styles).
3. **Impeccable Provenance Byte-Count Correction:**
   - Recorded in `impeccable-provenance-erratum-2026-11-02.md` (`39705ea7c8b670a0bcd69ee8b4b867ed95928329677ffc2226c2e3c3962bb103`) and in the updated `implementation-packet.md` / `report.md`: all 18 SHA-256 digests matched `data/syncloom-text-ui-challenge/impeccable-source/source-receipt.json` (`7e3ba41a125f342c34b69d126a3b189b86b5973bb15d77cc002538b5101774dc`), while the 18 byte counts are corrected to the actual verified counts (`161,375` bytes total vs `126,119` originally declared).
4. **Second-Round Challenger Objections (`O1`-`O4` in `second-round-objections.md`):**
   - Answered in full in `decisions/challenge-response-2026-11-02.md`: (O1) retracted the voluntary `Escaped<'a>` `Display` wrapper claim above (since raw `String`/`&str` still implements `Display` in `format!`) in favor of `syncloom_core::html::escape` + small auditable functions + inert-output regression tests, with `S2` as the fallback; (O2) distinguished original specimen measurements from prospective token contrast targets and retained `P1` as a competitive alternative without claiming `P2` superiority or remote parity; (O3) specified composed `(Piece.status, Piece.publish_status)` action rules including serialized `"posting"` and `"unknown"` no-blind-retry and `"posted"` no-new-send; (O4) specified `after`-only pagination on `GET /` and sequential `url::form_urlencoded::parse` handling on `POST /actions/thought`; and fixed `{contract.destination.handle}` (no double `@`) and lowercase `--accent-tint`.

