# 0007: Modularized Rust server-rendered HTML and CSS for the Syncloom browser studio

Status: proposed (independent challenge completed at `data/syncloom-text-ui-challenge/report.md`, SHA256 `3b148c7badae7a95d66068e1d40d68cdfd0ff1370b5fb3c2baf782b51823efa6`)
Owner: syncloom-v2-lab (delegated engineering choice under ADR-0001 D1/D6; captain owns any future relaxation of script-free CSP; firstmate owns any future auth-boundary route changes)
Method: decide@1.3.1, source baa7c65c88fa04eaa2d2167e78b24ff56e575e68
Checklist: 1.0.0, SHA256 8c88c2c9c524d97552f67f30f6c4ba25589516b9dc18a51b09f7962688e5b056
Identity: frontend/0007-text-studio-frontend-stack
OpenSpec: [polish-social-review](../../../openspec/changes/polish-social-review/proposal.md) (current baseline; implementation change `add-text-studio-frontend` to link back on creation)
Evaluation: executed local repository inspection at `c0584e87a808f457bd7b205da3009c485243d4e0` and completed independent challenge (`data/syncloom-text-ui-challenge/initial.md` SHA256 `bf962ca53fc2aa1504139447cf380539f0f8ca5f26e51136750c7fbfee902108`; `second-round-objections.md` SHA256 `140a044d50b8fa5d5dfbffff5f5f436303e019b6a259288a05013490cda65152`; `report.md` SHA256 `3b148c7badae7a95d66068e1d40d68cdfd0ff1370b5fb3c2baf782b51823efa6`)

## 1. Brief
Written at: `2026-11-02T14:04:00Z` (before executing the comparative evaluation)
Capture: consequential; pre-evaluation packet `decisions/frozen-pre-experiment.md` SHA256 `fec3e3b027d05a7c56daac9a1f128033adae66d54dae01137f7e78f97c638481`; brief revision `c0584e87a808f457bd7b205da3009c485243d4e0`; outcome date `2026-11-16` observed via `crates/syncloom-server/tests/` and `git log`; capture order 1 of 2 in task `syncloom-text-ui-design`.
Brief: Apply checklist Q1-Q5 ([frozen brief](frozen-pre-experiment.md#decision-1-frontend0007-text-studio-frontend-stack)). Select the frontend rendering and interaction stack for `syncloom.v2`'s text-first browser studio across the existing supported route surfaces (`GET /`, `GET /review/{piece_id}`, `GET /review/{piece_id}/edit`, and compatible styling/audit of `GET /review/{piece_id}/render` and shared HTML error responses).
Class: consequential; defines the rendering boundary, security header compatibility, and HTML escaping ownership across the browser studio.
Rollback mechanism/cost and residual harm: Reverting a server-rendered module split in `crates/syncloom-server/src/page/` is a single git revert with zero data migration (`Piece` and `DispatchIntent` files on disk are untouched). Residual harm of a wrong stack choice is either weakened `Content-Security-Policy` headers (if client scripts are introduced) or unescaped HTML interpolation (if raw string formatting is used carelessly).
Process budget: 1 scout session on `antigravity/gemini-4-argon` plus 1 independent blind challenger session on `openai-codex/gpt-6.1-sol`.
Human preference, separate from evidence: The captain stated `"we have a good foundation but specs are trash ... build it with rust all of it"` ([captain-words](../sources/captain-words.md)) and Main recorded `"script-free - keep CSP script-src 'none' and the landed no-script rule"` ([polish-social-review proposal](../../../openspec/changes/polish-social-review/proposal.md)).
Relevant unexplored gaps: Live multi-device phone access (`Q-ACCESS` in [rust-plan](../../research/2026-10-29-rust-plan/report.md)) remains out of scope because `syncloom-server` binds `127.0.0.1` only.

## 2. Frozen acceptance
Freeze: `2026-11-02T14:04:00Z`, immutable artifact [frozen-pre-experiment.md](frozen-pre-experiment.md) (SHA256 `fec3e3b027d05a7c56daac9a1f128033adae66d54dae01137f7e78f97c638481`).
Original frozen criteria/pass marks:
- **C1.1 (CSP & Boundary Compliance):** 100% compliance with `Content-Security-Policy: default-src 'none'; script-src 'none'; style-src 'self'; img-src 'self'; frame-src 'self'; object-src 'none'; connect-src 'self'; form-action 'self'; base-uri 'none'`, exact `Host`/`Origin` validation, and `csrf` hidden form tokens in `crates/syncloom-server/src/boundary.rs`.
- **C1.2 (Offline Nix & Hermetic Build):** Originally phrased as `0 uncached crates added to Cargo.lock` and `0 external JS/WASM bundlers required` under the locked Fleet Nix Rust 1.99.1 profile (`frozen-pre-experiment.md` had a typo saying `1.98.1`; canonical `docs/development.md` is `1.99.1`).
- **C1.3 (Complete Operation & Endpoint Coverage):** Script-free HTML forms and links cover the intended browser studio text workflow.
- **C1.4 (Single Owner per Rule & Maintainability):** `syncloom-core::Studio` owns domain validation, revision hashing, and channel bounds; HTML escaping has a single clear owner (`syncloom_core::html::escape`); cohesive modules pass Code Verify.
Post-experiment / pre-challenge scope amendment (`2026-11-02`, [scope-amendment.md](scope-amendment.md) SHA256 `1716f730b9ed1bc6af89c22c3cf4a0386c48a445e65ebd3905fac68272f4f0d9`):
- **Amended C1.2:** `docs/development.md:46,84-102,122` requires project-owned reproducible dependencies and hermetic tests, **not** an eternal zero-new-crates rule; missing Nix substitutes may be fetched during a reviewed lockfile update before hermetic tests run. Therefore **Option S2** is not disqualified merely because `askama`/`maud` is not currently in `Cargo.lock`.
- **Amended C1.3:** Testing all loopback API endpoints (`Main1312`) is satisfied by the API worker's synthetic test matrix plus testing each route's actual browser consumer where one exists. It does **not** authorize adding new credential/OAuth mutation forms (`/connections`), changing `boundary::is_page_path`, or expanding the first text slice into new image/carousel workflows.

## 3. Unknown-resolution plan
- **U1.1:** Which browser studio actions are already wired in `page.rs` vs `syncloom-core::Studio`, and which routes have no browser consumer? Resolution: code inspection of `crates/syncloom-server/src/{boundary.rs,page.rs,server.rs,social_routes.rs,meta.rs}` and `crates/syncloom-core/src/studio.rs`.
- **U1.2:** How do Option S1 (existing Rust SSR + `syncloom_core::html::escape`) and Option S2 (compile-time template crate such as `maud` or `askama`) compare once the artificial "no new crates" filter is removed? Resolution: comparative architectural evaluation and independent Codex-family challenge (Sections 4 and 5).
Research: N/A; all decisive facts are repository-internal rules and deterministic HTML/HTTP mechanics.

## 4. Evidence and options
### Claims

| ID | Claim | Status | Evidence |
| --- | --- | --- | --- |
| C1 | `syncloom-server` enforces `script-src 'none'` on every response and authenticates browser mutations on `boundary::is_page_path` (`/`, `/review/*`, `/actions/*`) exclusively through a single `csrf` field in `url::form_urlencoded` bodies, while `/v1/*` JSON mutations require `X-Syncloom-Token`. | verified | [boundary.rs](../../../crates/syncloom-server/src/boundary.rs), 2026-11-02, lines 62-104 |
| C2 | Main explicitly required keeping `CSP script-src 'none'` and the script-free server-form architecture when resolving `x-consent-script`. | verified | [polish-social-review proposal](../../../openspec/changes/polish-social-review/proposal.md), 2026-10-31, section `Request` |
| C3 | `[workspace.dependencies]` in `Cargo.toml` declares 32 entries (2 internal workspace crates + 30 external crates) and `Cargo.lock` currently contains none of `askama`, `maud`, `leptos`, or `dioxus`; however, `docs/development.md` permits adding reviewed, locked dependencies when needed. | verified | [Cargo.toml](../../../Cargo.toml), 2026-11-02, lines 32-68; [development.md](../../development.md), lines 46, 84-102, 122 |
| C4 | `crates/syncloom-server/src/page.rs` is 647 newline-terminated lines; during `polish-social-review`, Code Verify flagged `page.rs` complexity until `publish_controls` was extracted into a focused function. | verified | [page.rs](../../../crates/syncloom-server/src/page.rs), 2026-11-02, lines 1-647; [polish-social-review tasks](../../../openspec/changes/polish-social-review/tasks.md), lines 23-28 |
| C5 | `syncloom_core::html::escape` is the single shared owner of HTML entity escaping across both `crates/syncloom-core/src/visual.rs` and `crates/syncloom-server/src/page.rs`. | verified | [html.rs](../../../crates/syncloom-core/src/html.rs), 2026-11-02, lines 1-18 |
| C6 | Browser routes (`GET /`, `POST /actions/thought`, `GET /review/{id}`, `GET/POST /review/{id}/{edit,render}`, `POST /review/{id}/{approve,accept-cost,publish}`) call `syncloom_core::Studio` directly in Rust rather than calling `/v1/*` HTTP JSON endpoints; `page.rs:360` currently hardcodes `linkedin_text` on thought creation and `page.rs:110-145` accepts only `after` for cursor pagination. | verified | [page.rs](../../../crates/syncloom-server/src/page.rs), 2026-11-02, lines 110-145, 343-373, 444-582; [server.rs](../../../crates/syncloom-server/src/server.rs), lines 49-65, 168-203 |
| C7 | Whether a compile-time template engine (`askama` or `maud`) would compile cleanly under the workspace's strict clippy lint table without macro-expansion warnings or cache fetches has not been tested by installing it. | unverified | none: no dependency installation was authorized in this scout task |

### Assessment
Contradictions: The original freeze (`frozen-pre-experiment.md`) misstated `Cargo.toml` external dependency count as 26 (actual: 32 total entries, 30 external, C3), `page.rs` line count as 636/648 (actual `wc -l`: 647, C4), and treated current `Cargo.lock` membership as an immutable product rule rather than an initial build snapshot (C3). Under both the original and amended readings:
- **Option S1 (Modularized Rust SSR in `crates/syncloom-server/src/page/` + `studio.css`, reusing `Studio` and `syncloom_core::html::escape`):**
  - *Original freeze:* Feasible across `C1.1`-`C1.4` (noting that `page.rs` does not yet expose multi-channel checkboxes or reject/reopen/dry-run/export forms, C6).
  - *Amended scope:* Preserves the existing working transport, CSRF boundary, and single escaping owner (`syncloom_core::html::escape`) across the 4 existing route surfaces (`GET /`, `GET /review/{id}`, `GET /review/{id}/edit`, `GET /review/{id}/render` + shared error page) without altering auth boundaries.
- **Option S2 (Compile-time Rust template engine such as `askama` or `maud`):**
  - *Original freeze:* Failed literal `C1.2` (`0 uncached crates in current Cargo.lock`).
  - *Amended scope:* **Genuinely viable and the strongest competing alternative.** Provides default compile-time escaping and structural tag checking, at the cost of a lockfile update (C3, C7) and reconciling escaping ownership with `syncloom_core::html::escape` (C5).
- **Option S3 (`Leptos`/`Dioxus` client/hydrated WASM) & Option S4 (`React`/`Next.js`/`Vite` SPA):**
  - Fail `C1.1` (`script-src 'none'`) and the first-party Rust / no-JS-bundler rules under both the original and amended readings (C1, C2).
Transfer: Direct local verification of `boundary.rs`, `page.rs`, `server.rs`, and `Cargo.toml`.

## 5. Challenge
Applicability: consequential architectural choice; independent different-family challenge executed.
Challenger: OpenAI Codex (`PI_PROVIDER=openai-codex`, model `gpt-6.1-sol`, reasoning `xhigh`), trace `583631ab16b4845f28001b7e445f07fe` (`111` verified trace rows).
Commissioning input: `data/syncloom-text-ui-design/decisions/challenge-input.md` (SHA256 `7817abd8e303f4116b90317444b8f4d5a70a115d6267b7c54482e72de2c822df`), `decisions/frozen-pre-experiment.md` (SHA256 `fec3e3b027d05a7c56daac9a1f128033adae66d54dae01137f7e78f97c638481`), and `decisions/scope-amendment.md` (SHA256 `1716f730b9ed1bc6af89c22c3cf4a0386c48a445e65ebd3905fac68272f4f0d9`).
Evidence boundary: Canonical `main` at `c0584e87a808f457bd7b205da3009c485243d4e0`, retained Impeccable source at `data/syncloom-text-ui-challenge/impeccable-source/` (`source-receipt.json` SHA256 `7e3ba41a125f342c34b69d126a3b189b86b5973bb15d77cc002538b5101774dc`), and saved experiment files.
Initial pick and defense (`data/syncloom-text-ui-challenge/initial.md`, SHA256 `bf962ca53fc2aa1504139447cf380539f0f8ca5f26e51136750c7fbfee902108`):
- Picked **Option S1** (a small script-free Rust/Axum server-rendered surface with cohesive renderer modules and existing native forms), while explicitly defending **Option S2** as a genuine alternative under the corrected scope that must not be disqualified by an artificial "zero new crates" rule.
Agreement/disagreement and decision-owner resolution:
- **Agreement on S1:** Both primary and challenger select **S1** for the text-first slice because the existing transport, CSRF verification, and `syncloom_core::html::escape` architecture are already small, working, and under one trust boundary.
- **Corrections accepted from challenger:**
  1. Dropped the false "eternal zero-new-crates" justification; `S1` is chosen for simplicity and single-owner continuity on the 4-screen text surface, not because adding a crate to `Cargo.lock` is forbidden.
  2. Removed mandatory `/connections` credential/OAuth forms and auth-boundary (`boundary::is_page_path`) changes from the text-first scope.
  3. Corrected the distinction between browser HTML form handlers (which call `Studio` in Rust directly) and `/v1/*` JSON routes (which have no browser consumer except `GET /v1/pieces/{id}/assets/*` when assets exist).
  4. Noted that `/?status=...&channel=...` query filtering is not currently implemented in `Studio::list` (`studio.rs:556`) or `page.rs:110-145` and must not be faked in template code.
Strongest competing option/disconfirmation: **Option S2 (`askama` or `maud`)** if manual `escape()` calls or string-template reviewability in `page/` produce an escaping defect or Code Verify maintainability failure during implementation.
Recommendation revealed at: `2026-11-02` after `data/syncloom-text-ui-challenge/initial.md` (SHA256 `bf962ca53fc2aa1504139447cf380539f0f8ca5f26e51136750c7fbfee902108`) was durably saved (`008.msg`).
Objection and answer:
- *Challenger objections (`O1`, `O4` in `second-round-objections.md` and `decisions/challenge-response-2026-11-02.md`):*
  - `O1:` Manual `format!` HTML rendering in `S1` can miss an `escape()` call (and a voluntary `Display` wrapper does not prevent raw `String`/`&str` interpolation in `format!`), whereas `S2` enforces escaping by default.
  - `O4:` Proposing `/?status=...&channel=...` when `Studio::list` only supports `after` cursor pagination would falsely filter only a 20-item page slice, and repeated `channels` form fields cannot rely on a last-value-wins map.
- *Answer (`decisions/challenge-response-2026-11-02.md`):* Accepted without qualification.
  - For `O1`, we retract any claim that a voluntary `Display` wrapper gives compile-time escaping safety. `S1` relies on: (1) a single escaping owner (`syncloom_core::html::escape`), (2) small, directly auditable render functions across the 4 existing route surfaces (`home`, `review`, `edit`, and preserved `render` + shared `error`), and (3) deterministic inert-output regression tests (`crates/syncloom-server/tests/review_screen.rs`) asserting `<`, `>`, `&`, `"`, and `'` in thought, draft, slide, and routing fields render as entity-escaped text. We will not build a home-grown template/type framework; if keeping dynamic output auditable in `S1` proves fragile, `S2` (`maud`/`askama`) wins under the amended `C1.4` reading.
  - For `O4`, `GET /` keeps existing `Cursor { after: Option<String> }` (`deny_unknown_fields`, `page.rs:110-145`) backed by `Studio::list` (`studio.rs:556`, `<= 20` pieces per page) with no template-side filter slice and no unbacked cross-page sibling group navigation. `POST /actions/thought` parses `url::form_urlencoded::parse` sequentially after `boundary.rs`'s single-`csrf` check (`boundary.rs:45-96, 119-135`): rejecting any unknown field name (`!= "csrf" && != "text" && != "channels"`) with `400 invalid_request`, requiring exactly one `text` field (`400 invalid_request` if missing or duplicated), collecting all `channels` fields in submission order into `Vec<String>`, and delegating empty/duplicate/unknown channel validation to `Studio::create_thought` (`studio.rs:496-504`, which calls `Studio::parse_channels` at `studio.rs:164-177`). Final challenger disposition (`data/syncloom-text-ui-challenge/report.md` SHA256 `3b148c7badae7a95d66068e1d40d68cdfd0ff1370b5fb3c2baf782b51823efa6`): retains **S1** and keeps **S2** as the real competing alternative.

## 6. Experiment
N/A; stack selection is settled by repository architecture, security boundary analysis (`boundary.rs`), and the blind challenger comparison.

## 7. Decision
Choice and criterion-based reasons: **Select Option S1 (Modularized Rust/Axum server-rendered HTML and CSS in `crates/syncloom-server/src/page/` + `studio.css`, reusing `syncloom_core::Studio` and `syncloom_core::html::escape`)**.
- Preserves `script-src 'none'`, `Host`/`Origin` validation, and `boundary::is_page_path` without introducing client scripts or new security-sensitive route families (C1, C2).
- Keeps one HTML escaping owner (`syncloom_core::html::escape`, C5) and one domain owner (`syncloom_core::Studio`, C6) across the 4 existing route surfaces while splitting `page.rs` into small cohesive modules (`page/mod.rs`, `page/home.rs`, `page/review.rs`) so functions stay well within Code Verify complexity bounds (C4).
Rejected alternatives:
- **Option S2 (`askama`/`maud`):** Viable under the amended scope (not rejected for lockfile reasons), but deferred for this 4-screen slice because `S1` already works with `syncloom_core::html::escape` without introducing a second escaping owner or proc-macro template migration across unchanged routes.
- **Option S3 (`Leptos`/`Dioxus` WASM) & Option S4 (JS/TS SPA):** Rejected because they violate `script-src 'none'` and first-party Rust boundaries (C1, C2).
Human-owned questions: Any future relaxation of `script-src 'none'` (captain-owned) or addition of browser credential/OAuth management routes and auth-boundary changes (requires explicit owner review before implementation).
Premises:
- **P1.1:** Extracting `crates/syncloom-server/src/page.rs` into cohesive submodules (`mod.rs`, `home.rs`, `review.rs`) for the 4 existing route surfaces passes `cargo fmt --check && cargo clippy --all-targets -- -D warnings && cargo test` and Code Verify (`verify.py`) with zero complexity or escaping defects. Falsifying observation: any unescaped dynamic field or blocking complexity finding in `page/`; check date `2026-11-16`.

### Reconsideration trigger

| Signal | Owner | Action |
| --- | --- | --- |
| Manual `syncloom_core::html::escape` discipline or string markup in `crates/syncloom-server/src/page/` produces an escaping bug or fails Code Verify complexity review | syncloom-v2-lab | Reopen `frontend/0007-text-studio-frontend-stack` and adopt Option S2 (a locked compile-time template crate such as `maud` or `askama`) as the single HTML escaping owner |

Verification: Code 5.4.2 (`verify.py` / `findings.py`) during `syncloom-text-ui` implementation.

## 8. Outcome review
Owner/date: `syncloom-v2-lab` / `2026-11-16`
Resolvable predictions:
- **Pred-1.1 (by `2026-11-16`, source: `cargo test -p syncloom-server` and `verify.txt` in `syncloom-text-ui`):** The modularized `crates/syncloom-server/src/page/` implementation across the 4 existing route surfaces will pass `cargo fmt --check && cargo clippy --all-targets -- -D warnings && cargo test` and `verify.py` with 0 blocking complexity findings and `script-src 'none'` intact (confidence: 0.90, uncalibrated).
- **Pred-1.2 (by `2026-11-16`, source: `chrome-devtools-axi` E2E verification in `syncloom-text-ui`):** All supported browser text flows (multi-channel thought creation via `Studio::create_thought`, saved-piece review with separate review and delivery outcome states, draft text editing, revision-bound approval, X cost consent, and explicit publish) will complete in regular Chrome with zero console or CSP errors (confidence: 0.88, uncalibrated).
Batch review: Fleet coordinating owner; 1st `Method: decide@1.3.1` record in `syncloom.v2`.
Outcome-blind process review: pending (`2026-11-16`).
Observed outcomes: pending until `2026-11-16`.
Follow-up/supersedes: extends [ADR-0001](../0001-syncloom-v2-rebuild-decisions.md) D1; supersedes none.
Implementation: to be linked from the `syncloom-text-ui` OpenSpec change (`openspec/changes/add-text-studio-frontend/`).
