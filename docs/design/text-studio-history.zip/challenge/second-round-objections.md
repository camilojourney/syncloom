# Focused post-reveal objections for primary response through firstmate

2026-11-02. Initial `bf962ca53fc2aa1504139447cf380539f0f8ca5f26e51136750c7fbfee902108` remains unchanged. Sealed recommendation hash matches `e313c4e3ec3bc9cc7079d9894072751d6dade57524fa49bfafdd1c39b7116fa9`. I read the two drafts, recommendation, implementation packet, report and separate scope response only after inbox 002 authorized reveal. These are inputs for a challenge report, not approval of code. Please route the four numbered objections to Argon for a short written answer; no new experiment/research is requested.

## Initial agreement and strongest alternatives

I independently picked S1 and provisional P2, but not on the original asserted all-pass rationale. S2 is the strongest architecture alternative: automatic escaping/typed markup can remove interpolation mistakes that manual Rust formatting silently accepts. P1 is the strongest visual alternative: its sampled contrast passes, its previews already use sans, and neither serif editor discomfort nor amber/terracotta task confusion was measured. No exact platform fidelity was established for either.

The dated scope response is a meaningful improvement: it accepts S2 as viable, preserves only four existing route surfaces plus shared errors, excludes new auth/media workflows, separates review/outbox axes and labels previews approximate. Those amendments cannot retrospectively make the original experiment clean or the original all-pass claims verified.

## Four objections requiring exact answers as record inputs

### O1. Escaping guarantee is overstated

Scope response lines 19/26 proposes an `Escaped<'a>` Display wrapper "so dynamic piece fields cannot bypass escaping." With ordinary `format!`, raw `String`/`&str` remains Display and still compiles. A voluntary wrapper makes the same omission possible; it is not a compile-time guarantee.

Please acknowledge that limitation and state the intended smallest safety argument for S1: existing escape owner plus inert-output regression tests and bounded reviewable render functions, or an actually enforced API boundary. Do not add a home-grown template/type framework solely to defend zero dependencies. If S1 cannot keep dynamic output auditable without that machinery, S2 should win under the amended C1.4 reading. No dependency installation or prototype is needed to answer.

### O2. P2 is not a proved all-criteria winner; P1 is not empirically falsified

Recommendation section 2 and draft 0008 assert that P2 passes every criterion, "matches what LinkedIn, X, Bluesky, and Threads render on macOS" and avoids a P1 serif-wrap failure. Original PNGs embed pro-P2/anti-P1/P3 conclusions; the two narrow PNGs never show P2/P3. Metric files contain selected pairs and pixel widths, not all focus/hover/error pairs, `ch`, task success, platform reference captures or complete responsive screens. Both themes record P2 line-height 26.88px despite intended 1.72 dark leading. P2's action and posted badge also share green/mint families, so hue-family overlap is not a consistently applied P1 elimination rule.

Please explicitly distinguish the original reported measurements from the unsupported all-pass/remote-parity/empirical-user-experience claims and retain P1 as a competitive design alternative. P2 can remain the preferred restrained product direction without inventing evidence. The implementation should prove the actual product, not rerun palette campaigns until a favored result appears. New unknown-state token contrast claims in the scope response are prospective, not original measured results.

### O3. Compose review and delivery action rules; do not just add extra badge colors

The scope response correctly names two axes and no blind retry. Its table also says approved review enables Publish after X consent; that is insufficient when the same approved piece has `posting`, `unknown` or `posted` outbox state. `piece.rs:8-27,38-67`, `outbox.rs:46-55`, `studio.rs:924-940` distinguish these cases. The source serializes `posting` (a UI may label it Publishing); it does not serialize `publishing`.

Please confirm that final affordances derive from both axes and core behavior: posted is not a new send, posting/unknown must not advertise retry, definite refusal can have its cause-specific recovery, contained/exported must never read as remote success. Do not let a generic approved row override these constraints. Exact labels plus authored geometry can satisfy non-color cues without silently treating Unicode glyph icons as a zero-violation Impeccable pass.

### O4. Keep the simplest correct text surface, not an invented capability-to-form mapping

The original packet proposes `/?status=...&channel=...` while target Cursor/Studio::list only support an `after` cursor; filtering only the current 20-item page can falsely report no matches elsewhere. It also leaves zero-channel selection as either a default or error, and normal `axum::Form<...>` does not by itself demonstrate correct repeated-channel handling. Preserve one csrf token and strict scalar fields; repeated channel values must not be handled by a last-value-wins map or duplicate token leniency.

Please confirm these remain explicit implementation/spec choices, not already working capabilities: either limit the first text surface to existing supported operations or give filtering/pagination a core-owned tested contract and specify deterministic repeated-channel/empty/duplicate/unknown semantics. Keep the API worker's method/path matrix authoritative; no consumer is a valid result. New credential/OAuth forms, `/connections` auth classification and new media workflows stay excluded. Existing supported routes/assets remain preserved.

## Two concrete prospective packet corrections, not new decision gates

- Implementation packet section 5 says `@{contract.destination.handle}` although `routing.rs:156-160` already supplies the `@` prefix. Render the handle exactly once and label legacy missing routing as not recorded, not an invented connected/founder account.
- Light `--accent-Tint` versus dark `--accent-tint` in section 4 is case-sensitive CSS, not one remapped token. Normalize the prospective implementation token owner and test computed light/dark usage. These were not product bugs reproduced in this scout, only directly observed plan defects.

## Disconfirmation and simpler method already recommended

S1 loses to S2 if escaping omissions recur, the safety claim needs a custom template framework or cohesive functions remain unreviewable. P2 loses its implementation readiness if actual product pages clip at narrow/zoomed sizes, any required computed pair fails, dangerous lifecycle actions remain available, or state comprehension is ambiguous. Repair local markup/token defects first; do not infer that every defect requires a stack/palette replacement.

The simpler implementation is existing home/review/edit plus preserved render, shared error/result states, one shell stylesheet, one calm approximate preview rendering actual text/channel fit/routing and two explicit state labels. Reuse a small semantic palette by role instead of requiring a unique hue for each enum; keep exact state words and safety actions. Existing forms call Studio directly. No JSON proxy layer, auth console, new icon package, speculative navigation platform or palette experiment is justified by this challenge.
