# Blind initial frontend challenge

Saved 2026-11-02, before firstmate reveals the primary choices. Recipient: firstmate only.

## Independent picks

- **Stack: S1, a small script-free Rust/Axum server-rendered surface, with cohesive renderer modules and existing native forms.** This is a recommendation, not a claim of completed coverage or passing tests. S2 remains a genuine alternative under the corrected scope, not disqualified merely because its dependency is new.
- **Palette/type: P2 as a provisional product-UI direction, not a demonstrated experiment winner or an all-criteria pass.** Use its quiet light/dark surfaces, readable system sans and limited data monospace. Explicit labels and the actual lifecycle model matter more than six badge colors. P1 remains competitive: the experiment does not establish that serif draft reading is worse or that orange and amber are unusably confusable.
- **No option has demonstrated every frozen acceptance criterion.** In particular, P2 has no complete accessibility, exact-preview-fidelity, state-recovery or all-page evidence. Do not promote this design opinion into interface delivery, test success or authority to add credential forms.

## Identity, chronology and custody

Challenger family/provider: OpenAI Codex (`PI_PROVIDER=openai-codex`); model reported by the harness: `gpt-6.1-sol`; reasoning: `xhigh`. This is the one commissioned independent challenger, with no delegation or additional model/research calls. Independence is limited by shared training, a leading packet and the specimen's embedded judgments.

Target source: `/Users/camiloslaptop/.firstmate-homes/syncloom-v2-lab/projects/syncloom.v2`, read-only main, independently checked at `c0584e87a808f457bd7b205da3009c485243d4e0`. The disposable worker checkout is instead at `3a059a083887678e9d687378584c2f43e9f98da2`; I did not use it to silently substitute target contracts. No project files were changed.

Decide 1.3.1 and required challenge/record/evidence/checklist references were read. Checklist 1.0.0 hash matches its declared pin. The packet records source revision `baa7c65c88fa04eaa2d2167e78b24ff56e575e68`; I verified local bytes by hashing, not that revision's entire workflow history.

| Input | SHA256 verified locally |
| --- | --- |
| `design/decisions/challenge-input.md` | `7817abd8e303f4116b90317444b8f4d5a70a115d6267b7c54482e72de2c822df` |
| `design/decisions/frozen-pre-experiment.md` | `fec3e3b027d05a7c56daac9a1f128033adae66d54dae01137f7e78f97c638481` |
| `design/decisions/scope-amendment.md` | `1716f730b9ed1bc6af89c22c3cf4a0386c48a445e65ebd3905fac68272f4f0d9` |
| `design/impeccable-pin-license.md` | `92de0387932c89905c773092cd82aa448432a468687dacbfb3f7938c415cedf6` |
| supplied `impeccable-source/source-receipt.json` | `7e3ba41a125f342c34b69d126a3b189b86b5973bb15d77cc002538b5101774dc` |
| Decide checklist | `8c88c2c9c524d97552f67f30f6c4ba25589516b9dc18a51b09f7962688e5b056` |

Here `design/` abbreviates the authorized `data/syncloom-text-ui-design/` directory, not a repository path. Full paths, exact image/metric hashes and all 18 supplied Impeccable source hashes are in `input-hashes.json` beside this note.

The original freeze declares `2026-11-02T14:04:00Z`. The separate amendment is dated 2026-11-02 and explicitly **after the experiment, before this challenge/implementation**, applying Main1304/Main1312 to repair scope and authority, not introduce a newly discovered preference. I preserve that order and reason; original measurements are not rescored as though the amendment predated them. Those historical timestamps/authority reports are recorded claims, not independently authenticated execution receipts.

The originally recorded `/tmp/.../impeccable` source had been removed. I stopped on a concrete evidence block. Firstmate supplied exact-ref source bytes through inbox 001, acknowledged by moving it to `handled/`, and resolved the block. Local hashing confirms all 18 declared digests match the supplied bytes. **All 18 declared byte counts are wrong**, including LICENSE 10,766 actual versus 11,356 declared. The receipt preserves the discrepancy. Upstream retrieval and commit attribution are firstmate-reported, not a fresh outside fetch by me. LICENSE section 4 and NOTICE support retaining the license/notices, marking modifications and preserving attribution; do not copy/execute the network-downloading launcher. Its context command and detector were not run. Planning used source guidance directly.

Still unread at this save: `decisions/recommendation.md`, both authored decision drafts, `implementation-packet.md`, primary `report.md`, private primary notes. No outside research, palette reruns, browser session, dependency installation, live model/platform calls, real posts or private platform credentials were used.

## Input framing and evidence asymmetry

1. **Substantial framing leak, despite no explicit recommendation reveal:** P2 has much more prescriptive detail than competing options. The original palette PNGs themselves contain authored conclusions: P1 says "Terracotta CTA collides with warm amber draft badge"; P2 says "Unified sans matches LinkedIn, X, Bluesky & Threads feeds" and "6 non-colliding state pills"; P3 explicitly says its body/CTA fail. These are arguments embedded in supposedly comparative stimuli, not measurements. I saw them only while inspecting the required original images. This is not a clean conclusion-blind visual comparison, and later agreement cannot be counted as independent corroboration.
2. **Unequal content:** B0 has only three badges and no matching preview panels; variants have different preview copy and counters. P1 even includes an illustrative X 182/280 count while the displayed prose has a separate 266-character label. No saved core-generated expected-value fixture ties these examples together. The comparison cannot establish exact counting or preview fidelity.
3. **Incomplete visual coverage:** both 390px PNGs show B0 and only the upper portion of P1. They show no P2/P3 mobile render. Light desktop cuts off lower P2/P3 controls; dark desktop starts scrolled below the top. Metrics report all variants, but the screenshots do not visually establish every variant's narrow-layout craft or operability.
4. **The packet changes some original wording:** frozen C1.2 says Rust 1.98.1, while the challenge packet says 1.99.1; current target docs/toolchain support 1.99.1. The freeze says page.rs 636 lines and 26 dependencies; target `wc -l` reports 647 lines (newline-count convention) and TOML parsing counts 32 workspace dependency entries, 30 external. Cargo.lock contains none of askama/maud/leptos/dioxus, but absence from a lockfile does not prove absence from every cache. These precision defects do not decide the UI stack.
5. **Overstrong hard constraints:** the adopted contract supports reproducibility and hermetic tests, not an eternal zero-new-crates rule. `docs/development.md:46,84-102,122` keeps dependencies project-owned and explicitly allows obtaining missing Nix substitutes before hermetic tests. A new, reviewed and locked template dependency can fit that contract. The frozen zero-uncached mark remains an original restriction; it is not a demonstrated product requirement.
6. **Overstrong aesthetic claims:** pinned `operate.md:13` says one family is "often right", not mandatory. `typeset.md:46` makes 16px the ordinary floor with scoped exceptions. P1 already uses sans in platform previews. A generic sans category is not verification of exact platform fonts, line breaks, fold positions or remote layouts. A serif editor is not in itself an Impeccable ban.

## Stack: every real option against the original freeze

Legend: feasible = mechanism can meet the requirement; unknown = not demonstrated here; fails = contradicts the literal original rule. Feasibility is not an executed test pass.

| Option | C1.1 CSP/session boundary | C1.2 cached existing lock/toolchain | C1.3 every listed capability script-free | C1.4 one rule owner/maintainability |
| --- | --- | --- | --- | --- |
| S1 existing Rust SSR, modularized | Feasible without boundary change; uses existing form-token path | No new crate required; final fmt/clippy/tests not run here | Forms/links can cover intended text actions, but current app does NOT already expose all listed actions; filters/core/API scope must be checked | Reuse Studio and html::escape; coherent rendering helpers avoid an unmaintainable string monolith; proposed layout is not proof of quality |
| S2 compile-time Rust templates | Feasible; a template engine does not require browser scripts | Needs a reviewed dependency/lock update, so does not satisfy literal current-lock-only framing; cache availability and actual toolchain build unverified | Same native forms/links as S1; no inherent functional deficit | Strongest alternative: typed structure and default escaping can reduce injection/markup mistakes, but exact engine/version/escape contexts and integration are unverified; replace ownership rather than double-escape or copy rules |
| S3 Leptos/Dioxus client/WASM as described | Fails script-src none through required glue/hydration; no authority to weaken CSP | Additional target/framework/glue not within frozen build profile | As described depends on client execution; fails script-free requirement | Can call existing API but adds state/transport surface without resolving core ownership; not assessed by running it |
| S4 React/Next/Vite SPA | Fails script-free CSP and first-party Rust rule | Adds external JS tooling outside frozen profile | Fails script-free execution as described | JSON reuse does not rescue unauthorized language/execution boundaries; separate client validation risks duplication |

S3 implemented as a completely non-hydrated server-only renderer would be a materially different S2-like option, not evidence that the frozen S3 passes unchanged. Native-only desktop was excluded by the accepted browser-surface decision, not by my taste.

### Corrected-scope reading, assessed separately

S1 and S2 both remain technically viable. I prefer **S1 now because the text workflow already has a small, working transport and escaping architecture that can remain under one trust boundary**, not because an uncached crate is forbidden or because of development effort. Cohesive extraction is supported by the actual publish-controls extraction in `openspec/changes/polish-social-review/tasks.md:23-28`; a template dependency has not yet shown an answer-changing safety/maintainability benefit in this small slice. If escaping or reviewability remains fragile after coherent extraction, reopen S2 rather than preserving zero-dependency identity at the expense of correctness.

S2 is not inherently less secure or less maintainable. Its concrete implementation needs deterministic escaping/context tests, an actual pinned engine/version, normal dependency review and a reproducible build. Automatic template escaping should not be defeated with arbitrary trusted-HTML or pre-escaped dynamic strings. The existing renderer of visual HTML also owns escaping; integration must state the real ownership boundary rather than claiming a duplicated escape function is harmless. No experiment or install was authorized to decide this further.

S3/S4 remain excluded by the unchanged Rust/script-free boundaries even after scope correction. No current text interaction demonstrates a need to reopen those boundaries.

## Palette/type: every real option against the original freeze

The four saved metric files are **reported results of the primary's Chrome experiment**. I verified their bytes and read their values, and personally inspected the PNGs, but did not rerun the measurement or inspect an independently retained metric-collection implementation. They report no horizontal overflow for each option at both widths/themes. They do not record actual `ch` measurement, all foreground/background pairs, focus/hover/error/disabled checks, accessible names or core-generated preview fixtures.

| Option | C2.1 size/measure/responsive | C2.2 all contrast pairs + non-color cues | C2.3 six distinct states/non-collision | C2.4 four faithful previews + no craft bans |
| --- | --- | --- | --- | --- |
| B0 incumbent | Fails original >=16px draft floor (15px); reported no overflow does not prove no clipping | Sampled pairs pass, but no authored dark mode and missing non-color/status coverage | Fails original specimen: one badge background, three states only | Existing eyebrow/numbered scaffold and fluid heading conflict with pinned directions; no four-platform fidelity proof |
| P1 editorial | 16.5px prose and reported no overflow; desktop `ch` and every control unknown | Recorded samples pass in light/dark, including CTA 7.31/5.30; all-state/focus completeness unknown | Six sampled badge backgrounds; alleged amber/orange collision is an authored judgment, not measured task confusion | Sans previews are as eligible as P2; serif draft is not a ban. Glyph-icon treatment and exact preview claims require disposition; fidelity not verified |
| P2 mineral botanical | 16px prose and reported no overflow; 611px desktop width is not a verified `ch` measure; mobile visuals absent | Recorded samples pass, including CTA 8.77/9.04; no full pair/focus/keyboard proof | Six backgrounds, but posted and CTA share botanical/mint color families; "non-colliding" not established by uniqueness count | Unified sans is coherent product typography, not exact remote fidelity; glyph icons and all craft rules not cleared |
| P3 cobalt | Fails frozen body floor at 14px despite reported no overflow | Dark CTA recorded 4.47:1 fails ordinary-text 4.5:1; do not round it to a pass | Six backgrounds alone cannot establish state recognition; indigo appears in actions and contained state | Decorative mono headings conflict with guidance; four-platform fidelity unverified |

Original result: B0 and P3 have explicit frozen failures. **Neither P1 nor P2 has demonstrated all four prior pass marks.** Do not replace "unknown" with "pass" to obtain a winner.

### Corrected-scope reading, assessed separately

P2 is my **provisional** pick for its unified editing/review voice, legible ordinary body size, quiet reading surfaces and a restrained action system. These are design judgments relevant to repeated Operate/Read use, not measured user-comfort or speed improvements. No human reading/comprehension/correction task, semantic-confusion test, color-vision simulation or exact remote comparison was run. P1 remains the strongest alternative with comparably passing sampled contrast and a plausible reading role for its serif. There is no evidence here that changing P1's prose face or modest accent adjustment would cost usability; those would be explicit variants, not retroactive passes for the frozen specimen. B0 could be repaired, but that is likewise not the frozen incumbent. P3 can be repaired too, but frozen compactness/decorative mono have no demonstrated advantage for this text-first goal.

Pinned guidance introduces unresolved details the packet omits:

- `craft-floor.md:40` discourages Unicode glyphs standing in for an icon system. All three new specimens use such glyph prefixes. At minimum record the conflict/disposition; use explicit labels with consistent authored geometry if a non-color shape is needed. A six-glyph count is not automatically zero craft-floor violations. The file distinguishes category defaults from absolute bans, so do not invent a blanket prohibition broader than its words.
- `operate.md:13-16`, `typeset.md:8,46-49` are nuanced guidance, not proof of one best face. `craft-floor.md:12` gives 65-75ch, `typeset.md:47` gives 45-75ch, and the original brief pins 45-75ch. State the applicable reading role and use real face metrics; do not silently tighten it to eliminate an option.
- P2 declares dark leading compensation, but both saved light/dark metrics report **26.88px**, not the proposed 27.52px (16 x 1.72). P1 similarly stays 28.875px. Intended tokens are not computed evidence of compensation; weight/tracking are not recorded.
- System fonts are permitted for product UI by `operate.md`; no remote font is needed. Current CSP has no font-src exception, so do not quietly add a web-font fetch or change the boundary to pursue imagined platform fidelity.

## Actual lifecycle model and smallest robust implementation surface

### Preserve two dimensions, not an invented six-state enum

Verified source: `crates/syncloom-core/src/piece.rs:8-27,38-67` has three review states and a separate publish_status. `outbox.rs:8-55` has contained, exported, posting, posted, refused, consent_required, rate_limited, unreachable and unknown. **Unknown is not rejected or definitely failed; posting is not posted.** An approved piece can have an uncertain delivery outcome. Show review state and delivery outcome separately, with explicit words and recovery instructions. Six palette categories may reuse visual roles but cannot erase actual states or imply a linear six-step workflow.

Only posted means platform-confirmed post ID; contained means local outbox/nothing sent; exported means local handoff/no remote post. Preserve `outbox.rs:46-55` retry policy: no blind repeat for posting/unknown and no repost for posted. Retain revision-bound approval and cost consent bound to revision/estimate/date (`page.rs:22-85,304-341,561-582`). Editing invalidates review/assets (`piece.rs:61-67`). No UI redesign should invent a safer outcome than the core recorded.

### Surface inventory, not six mandatory new pages

Verified existing routes: `server.rs:49-65` serves home, piece review, editor/render action pages, actions/thought and CSS; `page.rs:93-101` renders shared HTML errors. Platform/asset previews are already a section within review, not necessarily a standalone page. The smallest robust text surface is:

1. Home/workspace: thought intake and saved-piece navigation; add text-relevant channel choice/filter affordances only against actual available core semantics.
2. Review: exact saved text, conservative per-channel fit/unit information and routing review target; approximate local preview honestly labeled; separate approve, explicit publish and truthful result/recovery.
3. Edit: exact saved text and revision check, no approval in the editor.
4. Shared error/empty/result states, plus preservation/audit of the already existing render page and asset routes when shared components change. No new image/carousel workflow in this slice.

A read-only local connection-status summary is optional, not a required new security-management screen. Current queue cursor only accepts `after` (`page.rs:110-145`), and `Studio::list` is the actual discovery owner (`studio.rs:556`); `/?status=...&channel=...` is not an already-supported API just because the option text names it. Do not duplicate filtering/revision/domain rules in template code. Current forms also hard-code LinkedIn thought intake and omit some listed transitions/dry-run/export (`page.rs:444-549`); these are coverage gaps, not evidence that Rust forms cannot support them.

### Capability mapping is not permission for new auth or media

`server.rs:168-203` shows the JSON thought/review/publish handlers call Studio. Browser form adapters separately call the same Studio (`page.rs:444-582`); they are **not JSON API consumers**. Test each actual method/path synthetically under the API worker's authoritative matrix, and test its actual consuming page where one exists. Correctly report "no browser consumer" for other routes instead of inventing forms to fill the table.

Credential entry, OAuth start/wait/complete, refresh/sign-out and route classification changes are a genuine security-sensitive dependency if someone proposes adding them. `boundary.rs:62-104` distinguishes page/form csrf from JSON X-Syncloom-Token by path; inventing `/connections` mutations changes how requests are authenticated unless deliberately routed/reviewed. Existing Bluesky sign-in takes app_password (`social_handlers.rs:14-35`); this must not be treated as routine text styling. Read-only status and existing core auth operations do not authorize new credential persistence, account use or worldwide access. Route those concrete changes to firstmate's explicit owner review before implementation, not to a generic palette decision. Template dependency review is also real supply-chain/output-safety work but is not intrinsically authorization to change auth boundaries.

Conservative app fit is verified locally by `channel.rs:89-184`: LinkedIn scalar-character rules, conservative weighted X units, Bluesky graphemes plus bytes, Threads bytes, other channel character bounds. `routing.rs:10,177-209` says destinations are review targets, not connected-account or publish permission. Display limits as app checks and X pricing as the dated estimate already labeled in `page.rs:330-338`, not current independently verified platform policy or a charge. Preserve exact text/whitespace; never truncate the actual review content to mimic an unverified remote fold.

## Evidence and execution limits

Verified locally: packet/source hashes, target main HEAD, inspected source/contract contents, four saved PNGs, values present in four saved metric files, discrepancy in all 18 pin byte counts, and received trace rows. Reported, not independently executed here: original Chrome experiment environment, timing and collection correctness; primary task's historical tests/Code Verify. Unverified: complete frontend quality, remote fonts/layout/current policies, new dependency behavior/build, task-completion/comprehension benefit and every original pass mark.

Executed command families: `git -C <read-only-main> rev-parse HEAD`; own checkout `git status --short`; absolute-path `find`, `rg`, `wc -l`; `shasum -a 256` and Python stdlib SHA256/TOML counting; read-tool inspection of named evidence/source. No Cargo, OpenSpec, Code Verify, API journey or new browser experiment was run. Thus no test-pass claim, generated screenshot claim or implemented-frontend claim follows. All OpenSpec commands, if later used, must retain `OPENSPEC_TELEMETRY=0 DO_NOT_TRACK=1`; none were needed here.

Tracing: read `fleet-system/system/skills/TRACING.md`; native telemetry record identifies own trace `583631ab16b4845f28001b7e445f07fe`, run `05cfe0bf-841e-4704-bfff-862995efefc1`, sampled true. A v2 observation GET scoped by that traceId returned HTTP 200 and 111 rows, every row matching the own trace, at `2026-11-02T14:47:19.075479+00:00`. See `trace-receipt.json`. First attempt with the OTLP-exporter header got HTTP 401; the existing `langfuse_report.credentials/http` integration then succeeded using credentials held only in memory. No service/config changes, token values, span input/output content, scores or unrelated traces were accessed/retained. Receipt is received-tracing evidence, not task-quality proof.

## Questions for the reveal round

Please reveal the separately recorded primary choices and exact objections/answers through firstmate. I will then defend the strongest competing option, identify disconfirmation and a simpler method, and preserve disagreement in report.md. Key concerns already fixed in this initial record are: no false all-criteria palette pass, no zero-dependency pseudo-contract, no UI-per-API/auth expansion, no six-state semantic collapse and no independently verified platform fidelity claim.
