# Impeccable Pin, License, and Project-Local Preservation Record

## 1. Upstream Provenance

- **Source Repository:** `https://github.com/pbakaus/impeccable`
- **Retrieved Via:** `gh-axi repo clone pbakaus/impeccable` (into disposable scratch `/tmp/fm-syncloom-text-ui-design/impeccable`)
- **Immutable Commit SHA:** `e89e3ada3e875a89ac2c5d33d11e65ebef6fe285`
- **Commit Date:** `2026-11-01T14:26:36Z`
- **Commit Subject:** `Sync generated provider output`

## 2. License and NOTICE Verification

- **License:** Apache License, Version 2.0 (January 2004), Copyright 2025 Paul Bakaus
  - Path in upstream repo: `LICENSE`
  - SHA-256: `02bb8c3b4e70190e3986c0404ad2fd8d639b4f534252d82379cc1b502b6d1812`
- **NOTICE File:** `NOTICE.md`
  - Path in upstream repo: `NOTICE.md`
  - SHA-256: `c60a093c2845fd9fb82f9c6f742ece31f379f8190b535309d32d66c45ccffdcb`
  - Content summary: Attributes `skill/reference/ios.md` and `skill/reference/android.md` to ehmo's `platform-design-skills` (`https://github.com/ehmo/platform-design-skills`, MIT License).
- **Redistribution & Attribution Obligations (Apache-2.0 Section 4):**
  1. Include a verbatim copy of `LICENSE` (Section 4a).
  2. Cause any modified files to carry prominent notices stating that the files were changed (Section 4b). If preserved verbatim without modification, record their exact SHA-256 digests.
  3. Retain all copyright, patent, trademark, and attribution notices (Section 4c).
  4. Include a readable copy of `NOTICE.md` (Section 4d).

## 3. Exact Source Subset for Project-Local Preservation in `syncloom.v2`

The implementation worker (`syncloom-text-ui`) MUST preserve the following read-only documentation/skill subset under `.agents/skills/impeccable/` (or `docs/design/impeccable/` if preferred to avoid global/harness skill auto-discovery side effects; **recommended path:** `docs/design/impeccable/` so no agent harness attempts to execute `{{scripts_path}}/impeccable`) and MUST NOT copy `skill/scripts/impeccable`, `skill/scripts/impeccable.cmd`, or any binary/installer script (which would attempt network downloads into `~/.impeccable/bin`).

| Upstream Path at `e89e3ada3e875a89ac2c5d33d11e65ebef6fe285` | Project-Local Path | SHA-256 | Bytes |
|---|---|---|---:|
| `LICENSE` | `docs/design/impeccable/LICENSE` | `02bb8c3b4e70190e3986c0404ad2fd8d639b4f534252d82379cc1b502b6d1812` | 11356 |
| `NOTICE.md` | `docs/design/impeccable/NOTICE.md` | `c60a093c2845fd9fb82f9c6f742ece31f379f8190b535309d32d66c45ccffdcb` | 396 |
| `.pi/skills/impeccable/SKILL.md` | `docs/design/impeccable/SKILL.md` | `1771f63c1b51d5546399698b981da70e601662997045ba67215338a5435b6279` | 8543 |
| `skill/reference/craft-floor.md` | `docs/design/impeccable/reference/craft-floor.md` | `086e731940b72db13d9693b575db377a7b102729a56da5c79a21461635695c87` | 5571 |
| `skill/reference/operate.md` | `docs/design/impeccable/reference/operate.md` | `e5bf4980c547e60b091f82f38d0eec4cc3ab85610b4b15ec8f1d86584f9eb404` | 3846 |
| `skill/reference/mode-operate.md` | `docs/design/impeccable/reference/mode-operate.md` | `7a52dd7a94ee75f6ae89542c86a1b6e1d306812b16e0d9dbf12d4acad44d148b` | 3981 |
| `skill/reference/mode-read.md` | `docs/design/impeccable/reference/mode-read.md` | `a569989e6a3d6453b4c45e9474e162a15cc54e11732ac6baa7990a6e7cccc0b5` | 3772 |
| `skill/reference/critique.md` | `docs/design/impeccable/reference/critique.md` | `f2ece6380e378ab644d0508adf10e213eb2d6e241e3d7339727fb8e61cd2d39b` | 29973 |
| `skill/reference/audit.md` | `docs/design/impeccable/reference/audit.md` | `6f2850794a8e74fd07ab9410104f99e3f20dee5490d5e82c98880852203341d0` | 7206 |
| `skill/reference/polish.md` | `docs/design/impeccable/reference/polish.md` | `c504e12ea076fd1a57b8c9ece79fbb532c54226b2b6298c5c62fa889ae1dd34d` | 5095 |
| `skill/reference/typeset.md` | `docs/design/impeccable/reference/typeset.md` | `925720c1d610d2a08a6811001303f395e4b2c971ef3d2506fbce43b2a1303152` | 5074 |
| `skill/reference/colorize.md` | `docs/design/impeccable/reference/colorize.md` | `dcc0c3ebb76bd22c543f45d73c283e3890e5b8a44eb5053ca2f7fdd425635c32` | 3802 |
| `skill/reference/layout.md` | `docs/design/impeccable/reference/layout.md` | `14ba132b6168bf0a7498f8c3fbbb41b73ff704da5dc3688fd842807446e54a05` | 4769 |
| `skill/reference/clarify.md` | `docs/design/impeccable/reference/clarify.md` | `4738e125835bd6c166aec2622977c9bc59bada52aaeb186585ed38b3900860b5` | 3826 |
| `skill/reference/harden.md` | `docs/design/impeccable/reference/harden.md` | `fb00cb42a9cb17d717aefabc418bd4dcb1be540d95d8498d8e3bd4e3e0b2a0a3` | 8476 |
| `skill/reference/adapt.md` | `docs/design/impeccable/reference/adapt.md` | `004b339416187222206adee5ff08ef1fa9bc346d4ceba2932f770d640449ec6d` | 10969 |
| `skill/reference/distill.md` | `docs/design/impeccable/reference/distill.md` | `54be6eca781b8e2d0f7e850277b330cade905ee4df4d9986519aac27538af724` | 5106 |
| `skill/reference/quieter.md` | `docs/design/impeccable/reference/quieter.md` | `c4755f41462f3534195912b64333df94dbdd0f54b8f2da1c9ef69ce94d974896` | 4358 |
