# Dated Handoff Provenance Erratum: Impeccable Pin & Byte Counts

**Date:** `2026-11-02 UTC`
**Scope:** Provenance erratum for `impeccable-pin-license.md` (SHA256 `92de0387932c89905c773092cd82aa448432a468687dacbfb3f7938c415cedf6`) and `supervisor-checkpoint.md` (`007.msg`).
**Custody Note:** All original files (`impeccable-pin-license.md`, `supervisor-checkpoint.md`, `decisions/frozen-pre-experiment.md`, `decisions/0007-text-studio-frontend-stack.md`, `decisions/0008-text-studio-palette-and-typography.md`, `decisions/challenge-input.md`, `decisions/recommendation.md`, and `palette-experiment/*`) are preserved byte-for-byte unchanged. This erratum contains zero design recommendations and may be read before or during blind challenge.

---

## 1. Commit Pin String Correction (`supervisor-checkpoint.md`)

- **Erroneous string in `supervisor-checkpoint.md` line 5:** `e89e3ada3e875a89ac2c5d33d11e65ebd3905fac68272f4f0d9` (51 characters; malformed concatenation of the commit prefix and the trailing 20 hex characters of `scope-amendment.md`'s SHA-256).
- **Correct 40-character Git Commit SHA-1 for `pbakaus/impeccable`:** `e89e3ada3e875a89ac2c5d33d11e65ebef6fe285`

---

## 2. Durable Source Retention Location

The 18 read-only `pbakaus/impeccable` documents at commit `e89e3ada3e875a89ac2c5d33d11e65ebef6fe285` (fetched via `gh-axi` GitHub contents `GET` with zero code executed) are durably retained at:
- **Directory:** `/Users/camiloslaptop/.firstmate-homes/syncloom-v2-lab/data/syncloom-text-ui-challenge/impeccable-source/`
- **Verification Receipt:** `/Users/camiloslaptop/.firstmate-homes/syncloom-v2-lab/data/syncloom-text-ui-challenge/impeccable-source/source-receipt.json`

---

## 3. Manifest Byte-Count Correction (`impeccable-pin-license.md`)

In `impeccable-pin-license.md` Section 4, **all 18 SHA-256 digests were exact matches**, but all 18 entries in the `Bytes` column were erroneous manual estimates rather than actual `wc -c` byte lengths. Below is the verified comparison against `source-receipt.json` and the retained files on disk:

| Upstream Path (`pbakaus/impeccable` @ `e89e3ada3e875a89ac2c5d33d11e65ebef6fe285`) | Verified SHA-256 (Matches Original Manifest 18/18) | Original Declared Bytes (Wrong) | Actual Verified Bytes (`wc -c`) |
| --- | --- | ---: | ---: |
| `LICENSE` | `02bb8c3b4e70190e3986c0404ad2fd8d639b4f534252d82379cc1b502b6d1812` | 11,356 | **10,766** |
| `NOTICE.md` | `c60a093c2845fd9fb82f9c6f742ece31f379f8190b535309d32d66c45ccffdcb` | 396 | **503** |
| `.pi/skills/impeccable/SKILL.md` | `1771f63c1b51d5546399698b981da70e601662997045ba67215338a5435b6279` | 8,543 | **11,849** |
| `skill/reference/craft-floor.md` | `086e731940b72db13d9693b575db377a7b102729a56da5c79a21461635695c87` | 5,571 | **7,166** |
| `skill/reference/operate.md` | `e5bf4980c547e60b091f82f38d0eec4cc3ab85610b4b15ec8f1d86584f9eb404` | 3,846 | **5,200** |
| `skill/reference/mode-operate.md` | `7a52dd7a94ee75f6ae89542c86a1b6e1d306812b16e0d9dbf12d4acad44d148b` | 3,981 | **4,716** |
| `skill/reference/mode-read.md` | `a569989e6a3d6453b4c45e9474e162a15cc54e11732ac6baa7990a6e7cccc0b5` | 3,772 | **4,396** |
| `skill/reference/critique.md` | `f2ece6380e378ab644d0508adf10e213eb2d6e241e3d7339727fb8e61cd2d39b` | 29,973 | **48,194** |
| `skill/reference/audit.md` | `6f2850794a8e74fd07ab9410104f99e3f20dee5490d5e82c98880852203341d0` | 7,206 | **8,893** |
| `skill/reference/polish.md` | `c504e12ea076fd1a57b8c9ece79fbb532c54226b2b6298c5c62fa889ae1dd34d` | 5,095 | **6,612** |
| `skill/reference/typeset.md` | `925720c1d610d2a08a6811001303f395e4b2c971ef3d2506fbce43b2a1303152` | 5,074 | **6,263** |
| `skill/reference/colorize.md` | `dcc0c3ebb76bd22c543f45d73c283e3890e5b8a44eb5053ca2f7fdd425635c32` | 3,802 | **4,554** |
| `skill/reference/layout.md` | `14ba132b6168bf0a7498f8c3fbbb41b73ff704da5dc3688fd842807446e54a05` | 4,769 | **5,161** |
| `skill/reference/clarify.md` | `4738e125835bd6c166aec2622977c9bc59bada52aaeb186585ed38b3900860b5` | 3,826 | **4,607** |
| `skill/reference/harden.md` | `fb00cb42a9cb17d717aefabc418bd4dcb1be540d95d8498d8e3bd4e3e0b2a0a3` | 8,476 | **10,765** |
| `skill/reference/adapt.md` | `004b339416187222206adee5ff08ef1fa9bc346d4ceba2932f770d640449ec6d` | 10,969 | **11,330** |
| `skill/reference/distill.md` | `54be6eca781b8e2d0f7e850277b330cade905ee4df4d9986519aac27538af724` | 5,106 | **5,489** |
| `skill/reference/quieter.md` | `c4755f41462f3534195912b64333df94dbdd0f54b8f2da1c9ef69ce94d974896` | 4,358 | **4,911** |
| **Total (18 files)** | — | 126,119 | **161,375** |
