# syncloom.v2 Text Studio Frontend Implementation Packet (Post-Challenge Revision)

**Target Repository:** `syncloom.v2` at canonical `main` (`c0584e87a808f457bd7b205da3009c485243d4e0` or later)
**Governing Decisions:**
- `decisions/0007-text-studio-frontend-stack.md` (**Option S1**: modularized Rust/Axum SSR in `crates/syncloom-server/src/page/` + `studio.css`, chosen for existing single-owner transport/escaping simplicity across the 4-screen text surface, **not** an eternal zero-new-crates rule; **Option S2** remains the fallback if manual escaping or string templates prove fragile).
- `decisions/0008-text-studio-palette-and-typography.md` (**Option P2**: `Precision Ink & Mineral Botanical` Light/Dark tokens + `16px` system sans + tabular mono, chosen as a **provisional product-UI direction**, not an all-criteria specimen winner or proof of remote platform fidelity; **Option P1** remains the competing fallback).
- Incorporates all corrections from `decisions/scope-amendment.md` (`1716f730...`), `decisions/challenge-response-2026-11-02.md` (`1857bab6...`), and the completed independent challenge report (`data/syncloom-text-ui-challenge/report.md`, SHA256 `3b148c7badae7a95d66068e1d40d68cdfd0ff1370b5fb3c2baf782b51823efa6`).
**OpenSpec CLI Rule (Main1327):** Every `openspec` command must run with `OPENSPEC_TELEMETRY=0 DO_NOT_TRACK=1` while keeping required local OpenTelemetry active.

---

## 1. Authorized Text-First Screen & Route Inventory (4 Route Surfaces)

Per `decisions/scope-amendment.md` and `data/syncloom-text-ui-challenge/report.md`:
- **No new credential-entry or OAuth mutation pages (`/connections`) and no changes to `boundary::is_page_path` (`crates/syncloom-server/src/boundary.rs:94-96`) are included in this text-first slice.**
- **No new image or carousel workflow is added.** Existing `GET/POST /review/{piece_id}/render` and `GET /v1/pieces/{piece_id}/assets/*` routes are preserved and styled compatibly with `studio.css` so no supported route is left visually broken.
- **Omit unbacked cross-page sibling group navigation:** `Studio::show` (`studio.rs:575-578`) returns a single `Piece` and `Studio::list` (`studio.rs:556`) returns at most 20 pieces per page; do **not** infer a thought group's sibling drafts from a 20-item page slice or render unbacked sibling tabs on `/review/{piece_id}`. Every drafted piece is reachable from the workspace list on `GET /`.
- Every created/touched page must receive an explicit Impeccable critique and audit pass during implementation, and final quality must be proven with full-page screenshots and computed-style checks on the **actual built `syncloom-server` product pages** (Light & Dark x `1440x900` & `390x844`).

| Surface ID | Existing Browser Route(s) | Direct Rust Core Owner | Required Text-First Behavior & States |
| --- | --- | --- | --- |
| **Surface 1: Studio Workspace (Home)** | `GET /` (`?after=<cursor>`), `POST /actions/thought` | `Studio::list`, `Studio::create_thought` | **Left column (Thought Intake):** `textarea[name="text"]` (`minlength="8"`, required) + channel checkboxes `name="channels"` (defaulting `linkedin_text` checked; allowing selection from the verified `Channel` table in `channel.rs` via existing `Studio::create_thought`). **Right column (Saved Pieces):** renders pieces returned by `Studio::list` (with `after` cursor pagination only; do **not** invent template-side `/?status=...&channel=...` filters unbacked by `Studio::list`). Each card displays: (1) channel label, (2) `Piece.routing` review target (`@camiloexperience` EN / `@camilojourney` ES) when present, (3) **Review State (`Piece.status`)** badge and separate **Delivery Outcome (`Piece.publish_status`)** badge when present, (4) conservative `fit` summary (`char_count / max_chars count_unit()`), and (5) untruncated/clean draft excerpt linking to `/review/{id}`. Includes empty-store state. |
| **Surface 2: Piece Review & Approximate Local Preview** | `GET /review/{piece_id}`, `POST /review/{piece_id}/{approve\|accept-cost\|publish}` | `Studio::show`, `Studio::review`, `CostConsents::accept`, `Studio::publish` | Two-column workspace on wide (`1440x900`), single-column stacked on narrow (`390x844`). **Left column (Review & Dispatch Controls):** (a) Source thought + `ThoughtContract` (`destination.handle` labeled `Suggested review target (from source language, not a connected account)`, `thesis`, `visual_hook`, `products`); (b) Saved draft metadata (`fit.char_count / fit.max_chars count_unit()`, `fit.verdict`, full `revision` SHA-256 in tabular mono, `review_decision_id` when approved, `Edit draft` link to `/review/{id}/edit`, and secondary `Configure visual slides` link to `/review/{id}/render`); (c) Separate **Review State (`Piece.status`)** and **Delivery Outcome (`Piece.publish_status`)** banners/badges (Section 4.3); (d) Revision-bound `Approve exact revision` form (`Status::Approved`), X dated cost-consent form (`POST /review/{id}/accept-cost`), and explicit `Publish` form (`POST /review/{id}/publish`) with truthful `PublishResponse` receipt banner and no-blind-retry protection when `publish_status` is `posting` or `unknown`. **Right column (Approximate Local Text Preview):** renders the full untruncated `piece.text` (`white-space: pre-wrap`) inside an explicitly labeled **`Approximate local preview · Conservative app fit check`** card (Section 5). Existing visual asset cards (`<img>`/`<iframe>`) render below the text preview **only** when `piece.assets.is_some()` or `piece.visual.is_some()`. |
| **Surface 3: Edit Draft** | `GET /review/{piece_id}/edit`, `POST /review/{piece_id}/edit` | `Studio::show`, `Studio::review` (`text`) | Single-column focused editor (`max-width: 720px`) with **zero approve or publish controls** (`openspec/specs/studio-api/spec.md`). Shows channel bounds (`min_chars..=max_chars count_unit()`), source thought reference, `textarea[name="text"]` (`16px` / `1rem`, `line-height: var(--prose-leading)`), `Save changes` button (`csrf` + `expected_revision`), and `Return to piece review` link. |
| **Surface 4: Existing Render Previews & Shared Error View** | `GET /review/{piece_id}/render`, `POST /review/{piece_id}/render`, plus `page::error` (all 4xx/5xx HTML responses) | `Studio::show`, `Studio::render`, `Failure` | **Render Previews:** preserves existing slide/template form (`template`: `midnight`/`paper`, `slides` textarea, zero approve/publish controls) styled with the updated `studio.css` tokens so Light/Dark and `1440`/`390` layouts are clean and unclipped. **Shared Error View (`page::error`):** centered card displaying fixed contract message (`contracts/studio-api/errors/<code>.json`), error `code`, `X-Request-Id` in tabular mono, and recovery link back to `/review/{id}` or `/`, with zero echoed user input. |

---

## 2. Honest Endpoint-to-Consuming-Page Matrix

Browser HTML routes in `syncloom-server` call `syncloom_core::Studio` directly in Rust (`crates/syncloom-server/src/page.rs:444-582`); they are **not** HTTP callers of the `/v1/*` JSON endpoints. Executed synthetic test coverage of every `/v1/*` HTTP route is owned by the API worker's authoritative `endpoint-matrix.md` (`syncloom-api-e2e`).

### 2.1 Browser HTML Routes & Stylesheet (Direct `Studio` Callers, CSRF-Protected on `POST`)

| Method & Path | Rust Core Call | Browser Surface | Synthetic Success Case | Validation / Conflict Case | Auth / Boundary Refusal Case |
| --- | --- | --- | --- | --- | --- |
| `GET /` (`?after=...`) | `Studio::list` | **Surface 1 (Home)** | 200 HTML workspace + saved pieces list | 400 `invalid_request` HTML error page on invalid `after` cursor or unknown query param | 403 `host_not_allowed` / `origin_not_allowed` |
| `POST /actions/thought` | `Studio::create_thought` | **Surface 1 (Home)** form | 303 redirect to `/review/{first_piece_id}` | 422 `thought_too_short` (< 8 non-space chars); 422 `unsupported_channel`; 400 `invalid_request` | 403 `session_required` on missing/wrong `csrf`; 503/502/504 `provider_*` |
| `GET /review/{piece_id}` | `Studio::show` | **Surface 2 (Review)** | 200 HTML review & approximate local preview | 404 `piece_not_found` HTML error page | 403 `host_not_allowed` / `origin_not_allowed` |
| `GET /review/{piece_id}/edit` | `Studio::show` | **Surface 3 (Edit)** | 200 HTML draft editor (no approve/publish controls) | 404 `piece_not_found` | 403 `host_not_allowed` / `origin_not_allowed` |
| `POST /review/{piece_id}/edit` | `Studio::review` (`text`) | **Surface 3 (Edit)** form | 303 redirect to `/review/{piece_id}` (`pending_review`, new `revision`, `assets: null`) | 400 `invalid_request` (blank text); 409 `revision_conflict` | 403 `session_required` |
| `GET /review/{piece_id}/render` | `Studio::show` | **Surface 4 (Render)** | 200 HTML slide config (no approve/publish controls) | 404 `piece_not_found` | 403 `host_not_allowed` / `origin_not_allowed` |
| `POST /review/{piece_id}/render` | `Studio::render` | **Surface 4 (Render)** form | 303 redirect to `/review/{piece_id}` with rendered `assets` | 400 `invalid_request`; 409 `revision_conflict`; 503/502/504 `renderer_*` | 403 `session_required` |
| `POST /review/{piece_id}/approve` | `Studio::review` (`Approved`) | **Surface 2 (Review)** form | 303 redirect to `/review/{piece_id}` (`approved` + `review_decision_id`) | 409 `revision_conflict`; 409 `invalid_status_transition`; 409 `assets_required` / `asset_conflict` | 403 `session_required` |
| `POST /review/{piece_id}/accept-cost` | `CostConsents::accept` | **Surface 2 (Review)** form (`Channel::X`) | 303 redirect to `/review/{piece_id}` with session consent recorded for exact revision + estimate + date | 400 `invalid_request` (non-X piece); 409 `revision_conflict`; 409 `cost_confirmation_required` (estimate mismatch) | 403 `session_required` |
| `POST /review/{piece_id}/publish` | `Studio::publish` | **Surface 2 (Review)** form | 200 HTML review page with truthful `PublishResponse` receipt (`contained`, `posted`, or `unknown`) | 409 `approval_required`; 409 `revision_conflict`; 409 `cost_confirmation_required`; 409 `assets_required` | 403 `session_required` |
| `GET /studio.css` | Static `STUDIO_CSS` | All 4 Browser Surfaces | 200 `text/css; charset=utf-8` | 405 on `POST /studio.css` | 403 `host_not_allowed` / `origin_not_allowed` |

### 2.2 Loopback `/v1/*` API Routes (Executed Coverage Owned by `syncloom-api-e2e`)

| Method & Path | Rust Core Call | Actual Browser Page Consumer | Notes for Browser & API Verification |
| --- | --- | --- | --- |
| `GET /v1/pieces/{piece_id}/assets/image` | `Studio::view_asset` | **Surface 2 (`GET /review/{piece_id}`)** `<img>` & link when `piece.assets.is_some()` | Serves verified PNG bytes (`ETag`, `Cache-Control: no-store`); 409 `assets_required` / `asset_integrity` if missing/tampered. |
| `GET /v1/pieces/{piece_id}/assets/carousel` | `Studio::view_asset` | **Surface 2 (`GET /review/{piece_id}`)** `<iframe>` & link when `piece.assets.is_some()` | Serves verified PDF bytes (`ETag`, `Cache-Control: no-store`). |
| `GET /v1/pieces/{piece_id}/assets/slides/{index}` | `Studio::view_asset` | **Surface 2 (`GET /review/{piece_id}`)** `<img>` & link when `slides_jpeg` present | Serves verified JPEG slide bytes (`ETag`, `Cache-Control: no-store`). |
| `GET /v1/session`, `GET /v1/health`, `GET /v1/pieces`, `POST /v1/thoughts`, `GET /v1/pieces/{piece_id}`, `PATCH /v1/pieces/{piece_id}`, `POST /v1/pieces/{piece_id}/publish`, `POST /v1/pieces/{piece_id}/export`, `POST /v1/pieces/{piece_id}/render` | `Boundary::token`, `Studio::*` | **None** (JSON API / CLI surface; browser uses the direct Rust `Studio` routes in Table 2.1) | Tested synthetically in `syncloom-api-e2e` (`endpoint-matrix.md`) and `crates/syncloom-server/tests/`. |
| `POST /v1/{linkedin\|mastodon\|meta\|x\|threads}/sign-in`, `GET /v1/{linkedin\|mastodon\|meta\|x}/sign-in`, `POST /v1/bluesky/sign-in`, `POST /v1/threads/complete`, `POST /v1/{bluesky\|x\|threads}/refresh`, `GET /v1/{linkedin\|mastodon\|meta\|bluesky\|x\|threads}/connection`, `DELETE /v1/{linkedin\|mastodon\|meta\|bluesky\|x\|threads}/connection` | `Studio::*`, `SocialPlatforms::*`, `Meta::*` | **None** (CLI / JSON API surface; no browser credential or OAuth forms in the text-first slice) | Tested synthetically against loopback fakes in `syncloom-api-e2e` (`endpoint-matrix.md`). Any future browser connection surface requires explicit security/owner review before implementation. |

---

## 3. Verified Impeccable Subset & Provenance (18 Read-Only Files)

Copy the 18 verified files from `/Users/camiloslaptop/.firstmate-homes/syncloom-v2-lab/data/syncloom-text-ui-challenge/impeccable-source/` (`pbakaus/impeccable` commit `e89e3ada3e875a89ac2c5d33d11e65ebef6fe285`, Apache-2.0) into `docs/design/impeccable/` (with a short `docs/design/impeccable/README.md` recording the commit pin and Apache-2.0 attribution per `LICENSE` Section 4 and `NOTICE.md`). **Never copy or execute `skill/scripts/impeccable`.**

| Retained Source Path | Target Repo Path (`docs/design/impeccable/...`) | Verified SHA-256 | Verified Bytes (`wc -c`) |
| --- | --- | --- | ---: |
| `LICENSE` | `LICENSE` | `02bb8c3b4e70190e3986c0404ad2fd8d639b4f534252d82379cc1b502b6d1812` | 10,766 |
| `NOTICE.md` | `NOTICE.md` | `c60a093c2845fd9fb82f9c6f742ece31f379f8190b535309d32d66c45ccffdcb` | 503 |
| `.pi/skills/impeccable/SKILL.md` | `SKILL.md` | `1771f63c1b51d5546399698b981da70e601662997045ba67215338a5435b6279` | 11,849 |
| `skill/reference/craft-floor.md` | `reference/craft-floor.md` | `086e731940b72db13d9693b575db377a7b102729a56da5c79a21461635695c87` | 7,166 |
| `skill/reference/operate.md` | `reference/operate.md` | `e5bf4980c547e60b091f82f38d0eec4cc3ab85610b4b15ec8f1d86584f9eb404` | 5,200 |
| `skill/reference/mode-operate.md` | `reference/mode-operate.md` | `7a52dd7a94ee75f6ae89542c86a1b6e1d306812b16e0d9dbf12d4acad44d148b` | 4,716 |
| `skill/reference/mode-read.md` | `reference/mode-read.md` | `a569989e6a3d6453b4c45e9474e162a15cc54e11732ac6baa7990a6e7cccc0b5` | 4,396 |
| `skill/reference/critique.md` | `reference/critique.md` | `f2ece6380e378ab644d0508adf10e213eb2d6e241e3d7339727fb8e61cd2d39b` | 48,194 |
| `skill/reference/audit.md` | `reference/audit.md` | `6f2850794a8e74fd07ab9410104f99e3f20dee5490d5e82c98880852203341d0` | 8,893 |
| `skill/reference/polish.md` | `reference/polish.md` | `c504e12ea076fd1a57b8c9ece79fbb532c54226b2b6298c5c62fa889ae1dd34d` | 6,612 |
| `skill/reference/typeset.md` | `reference/typeset.md` | `925720c1d610d2a08a6811001303f395e4b2c971ef3d2506fbce43b2a1303152` | 6,263 |
| `skill/reference/colorize.md` | `reference/colorize.md` | `dcc0c3ebb76bd22c543f45d73c283e3890e5b8a44eb5053ca2f7fdd425635c32` | 4,554 |
| `skill/reference/layout.md` | `reference/layout.md` | `14ba132b6168bf0a7498f8c3fbbb41b73ff704da5dc3688fd842807446e54a05` | 5,161 |
| `skill/reference/clarify.md` | `reference/clarify.md` | `4738e125835bd6c166aec2622977c9bc59bada52aaeb186585ed38b3900860b5` | 4,607 |
| `skill/reference/harden.md` | `reference/harden.md` | `fb00cb42a9cb17d717aefabc418bd4dcb1be540d95d8498d8e3bd4e3e0b2a0a3` | 10,765 |
| `skill/reference/adapt.md` | `reference/adapt.md` | `004b339416187222206adee5ff08ef1fa9bc346d4ceba2932f770d640449ec6d` | 11,330 |
| `skill/reference/distill.md` | `reference/distill.md` | `54be6eca781b8e2d0f7e850277b330cade905ee4df4d9986519aac27538af724` | 5,489 |
| `skill/reference/quieter.md` | `reference/quieter.md` | `c4755f41462f3534195912b64333df94dbdd0f54b8f2da1c9ef69ce94d974896` | 4,911 |
| **Total (18 files)** | — | — | **161,375** |

---

## 4. Provisional `Option P2` Token System & Two-Axis State Semantics (`studio.css`)

### 4.1 Color & Typography Tokens (with Verified Dark Leading Compensation)

```css
:root {
  color-scheme: light dark;

  --font-sans: -apple-system, BlinkMacSystemFont, "SF Pro Text", "Segoe UI", system-ui, sans-serif;
  --font-mono: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace;

  /* Typography & Reading Comfort */
  --prose-size: 1rem;          /* 16px floor */
  --prose-leading: 1.68;       /* 26.88px in Light mode */
  --prose-tracking: 0em;
  --prose-measure: 64ch;       /* within 45-75ch band */

  /* Light Theme: Precision Ink & Mineral Botanical (Provisional P2) */
  --bg-canvas: #F5F6F3;
  --bg-surface: #FFFFFF;
  --bg-subtle: #EBEEE9;

  --text-primary: #11201E;     /* 16.81:1 on surface */
  --text-secondary: #415450;   /* 8.05:1 on surface */
  --text-muted: #526661;       /* 5.92:1 on surface */

  --border-subtle: #D5DDD3;
  --border-strong: #8FA095;

  --accent-primary: #1B5442;   /* 8.77:1 with --accent-on-primary */
  --accent-hover: #133E30;
  --accent-on-primary: #FFFFFF;
  --accent-tint: #E6F0EC;

  --focus-ring: #B45309;       /* 5.02:1 on light canvas */
  --selection-bg: #CDE3DA;
  --selection-fg: #11201E;

  /* Axis 1: Review State Badges (Piece.status) */
  --badge-pending-bg: #FEF3C7;
  --badge-pending-fg: #78350F;    /* 8.15:1 */
  --badge-pending-border: #D97706;

  --badge-approved-bg: #DCFCE7;
  --badge-approved-fg: #14532D;   /* 8.30:1 */
  --badge-approved-border: #16A34A;

  --badge-rejected-bg: #E2E8F0;
  --badge-rejected-fg: #1E293B;   /* 11.4:1 */
  --badge-rejected-border: #64748B;

  /* Axis 2: Outbox Delivery Outcome Badges (Piece.publish_status) */
  --badge-contained-bg: #E0E7FF;
  --badge-contained-fg: #1E1B4B;  /* 12.98:1 */
  --badge-contained-border: #6366F1;

  --badge-exported-bg: #CFFAFE;
  --badge-exported-fg: #164E63;   /* 8.14:1 */
  --badge-exported-border: #0891B2;

  /* Bordered surface (NOT solid button fill) so Posted never mimics the primary CTA (prospective target: 10.6:1 L / 10.2:1 D) */
  --badge-posted-bg: #E6F4EA;
  --badge-posted-fg: #0D3B22;
  --badge-posted-border: #15803D;

  /* Distinct non-retryable caution token for posting / unknown (prospective target: 8.9:1 L / 10.3:1 D) */
  --badge-unknown-bg: #FAE8FF;
  --badge-unknown-fg: #701A75;
  --badge-unknown-border: #A21CAF;

  /* Retryable pre-post failure: refused / consent_required / rate_limited / unreachable */
  --badge-failed-bg: #FEE2E2;
  --badge-failed-fg: #7F1D1D;     /* 8.20:1 */
  --badge-failed-border: #EF4444;
}

@media (prefers-color-scheme: dark) {
  :root {
    /* Dark Mode Reading Compensation (verified on .prose / .draft-text / .preview-prose) */
    --prose-leading: 1.72;       /* 27.52px at 16px */
    --prose-tracking: 0.005em;

    --bg-canvas: #0D1312;
    --bg-surface: #141D1B;
    --bg-subtle: #1B2624;

    --text-primary: #ECF1EE;     /* 15.05:1 on surface */
    --text-secondary: #9FB0AC;   /* 7.60:1 on surface */
    --text-muted: #889B96;       /* 5.75:1 on surface */

    --border-subtle: #263532;
    --border-strong: #3E5450;

    --accent-primary: #34D399;   /* 9.04:1 with --accent-on-primary */
    --accent-hover: #6EE7B7;
    --accent-on-primary: #091E16;
    --accent-tint: #132A23;

    --focus-ring: #F59E0B;       /* 9.8:1 on dark surface */
    --selection-bg: #1F4E3D;
    --selection-fg: #ECF1EE;

    --badge-pending-bg: #2E210B;
    --badge-pending-fg: #FCD34D;    /* 10.88:1 */
    --badge-pending-border: #D97706;

    --badge-approved-bg: #0D2B1D;
    --badge-approved-fg: #86EFAC;   /* 10.83:1 */
    --badge-approved-border: #16A34A;

    --badge-rejected-bg: #1E293B;
    --badge-rejected-fg: #E2E8F0;   /* 11.2:1 */
    --badge-rejected-border: #64748B;

    --badge-contained-bg: #191E38;
    --badge-contained-fg: #C7D2FE;  /* 10.96:1 */
    --badge-contained-border: #6366F1;

    --badge-exported-bg: #0E2933;
    --badge-exported-fg: #67E8F9;   /* 10.47:1 */
    --badge-exported-border: #0891B2;

    --badge-posted-bg: #062E22;
    --badge-posted-fg: #6EE7B7;     /* 10.2:1 */
    --badge-posted-border: #10B981;

    --badge-unknown-bg: #3B0764;
    --badge-unknown-fg: #F5D0FE;    /* 10.3:1 */
    --badge-unknown-border: #C026D3;

    --badge-failed-bg: #311316;
    --badge-failed-fg: #FCA5A5;     /* 8.96:1 */
    --badge-failed-border: #EF4444;
  }
}
```

### 4.2 Craft-Floor Compliance (No Unicode Symbol Icons or Scaffold Bans)

- **No decorative Unicode symbol prefixes (`craft-floor.md:40`):** Do **not** prefix badges or links with `○`, `✓`, `▣`, `◫`, `●`, `×`, `↗`, or `←`. Instead, give `.status-badge` a consistent CSS-authored indicator (`::before` `8px x 8px` geometric shape: hollow ring for pending, filled circle for approved/posted, dashed square for contained/exported, diamond/triangle border or `2px` left bar for unknown/failed) alongside explicit words.
- **No `.eyebrow` kickers or `01 /` numbered section markers (`craft-floor.md:36-38`):** Remove all `<p class="eyebrow">` elements and `01 /`, `02 /`, `03 /`, `04 /` heading prefixes from `page.rs`.
- **Fixed `rem` Type Scale (`typeset.md:46-55`):** `h1` `1.5rem` (`24px`), `h2` `1.125rem` (`18px`), `h3`/prose `1rem` (`16px`, `line-height: var(--prose-leading)`, `letter-spacing: var(--prose-tracking)`, `max-width: var(--prose-measure)`), UI labels/buttons `0.875rem` (`14px`), metadata/hashes/counters `0.75rem` (`12px`, `font-variant-numeric: tabular-nums`).
- **Card Radius & Single Elevation (`craft-floor.md:42-43`):** `border-radius: 12px` on cards (`8px` on controls); `1px solid var(--border-subtle)` without simultaneous wide drop-shadows.

### 4.3 Two-Axis Lifecycle Display & Bounded Core Semantics (`Piece.status` + `Piece.publish_status`)

Never collapse review status and delivery outcome into a single 6-state badge, and never overclaim what `Piece` stores on disk (`piece.rs:8-27,38-67`, `outbox.rs:8-55`, `studio.rs:425-464,683-703,729-737,763-793,798-816,924-940`):

1. **Bounded Data-Model Truths (from `data/syncloom-text-ui-challenge/report.md`):**
   - **Review approval is not account or delivery readiness:** `Status::Approved` means a human approved this exact `revision` SHA-256; it does **not** verify that platform credentials, a connected account, a `SYNCLOOM_DELIVERY` grant, or permission for a live post are ready. When `publish_status` is `None`, label the delivery axis **`Delivery: No dispatch recorded for this revision`** (never `"Ready to publish"`).
   - **`Piece.publish_status` is a last-operation summary, not a complete history ledger:** `studio.rs:425-464` records exports under operation key `export:{target}` (distinct from `OPERATION_PUBLISH` at `studio.rs:729-737`) and `studio.rs:798-816` overwrites `Piece.publish_status` with `"exported"`. Therefore `"exported"` means **the last recorded operation wrote a local export bundle (not a remote post)**; it does **not** prove the piece was never posted by an earlier publish intent, nor does `outbox.rs:46-55` forbid a separate `OPERATION_PUBLISH` operation unless a publish intent itself is non-retryable.
   - **`"contained"` is intent-local and not solely an env-var indicator:** `studio.rs:683-703` also keeps unsupported delivery paths contained (e.g., `ManualExport` or LinkedIn visuals even when a platform grant exists), and `reserve_intent` (`studio.rs:763-793`) initially writes `"contained"` with zero attempts. Label `"contained"` as **`Delivery: Last publish intent saved locally (nothing sent by that intent)`**, stating the specific `reason` only when present on an immediate `PublishResponse`.
   - **Persisted `"posting"` is not proof of live in-progress work:** `outbox.rs:16` and `studio.rs:929-935` treat a saved `"posting"` marker found later as an **unconfirmed prior attempt** (converting it to `"unknown"` rather than retrying it). Never promise active background progress from a saved `"posting"` marker alone; label both `"posting"` and `"unknown"` as **unconfirmed / uncertain delivery outcome (`do not retry blindly`)**.
   - **`GET /review/{piece_id}` (`Studio::show`) returns `Piece`, not a full `PublishResponse` receipt:** On an ordinary `GET` or reload, `Piece` exposes `status` and `publish_status` (`Option<String>`), not `post_id`, `post_url`, `attempts`, `reason`, or `request_id`. Render full receipt details (`post_id`, `post_url`, `attempts`, `reason`, `request_id`) when returned by `POST /review/{piece_id}/publish`, and on `GET /review/{piece_id}` show the recorded `publish_status` honestly without inventing missing receipt fields or invoking a mutating publish call.

| `Piece.status` (Review Axis) | `Piece.publish_status` (Last-Operation Summary on `Piece`) | Honest UI State Labels (Review Badge + Delivery Badge) | Composed Action & Retry Rules on `/review/{piece_id}` |
| --- | --- | --- | --- |
| `pending_review` | `None` (or cleared on edit) | `Review: Pending review` (`.badge-pending`) · `Delivery: No dispatch recorded` | `Approve exact revision` enabled (unless `visual.is_some()` and `assets.is_none()`); `Publish` disabled (`approval_required`). |
| `rejected` | `None` | `Review: Rejected` (`.badge-rejected`) · `Delivery: No dispatch recorded` | `Approve` and `Publish` disabled; recovery is `Edit draft` (`/review/{id}/edit`) to create a new revision. |
| `approved` | `None` | `Review: Approved` (`.badge-approved`) · `Delivery: No dispatch recorded for this revision` | Does not claim account/delivery readiness. For `Channel::X`, requires `Accept estimated cost` (`POST /review/{id}/accept-cost`) for `(revision, total_micro_usd, pricing_as_of)`; then `Publish` form is enabled. |
| `approved` | `Some("contained")` | `Review: Approved` (`.badge-approved`) · `Delivery: Saved locally in outbox (nothing sent by that intent)` (`.badge-contained`) | Intent-local (`allows_new_attempt() == true` on `OPERATION_PUBLISH`). Shows exact `PublishResponse` `reason`/`request_id`/`attempts` when rendered from `POST /review/{id}/publish`, or notes that details are not stored on `Piece` on `GET`. |
| `approved` | `Some("refused" \| "consent_required" \| "rate_limited" \| "unreachable")` | `Review: Approved` (`.badge-approved`) · `Delivery: Last publish attempt not posted ({status})` (`.badge-failed`) | Intent-local (`allows_new_attempt() == true`). Shows cause-specific recovery guidance; allows a new publish attempt after resolving the cause. |
| `approved` | `Some("posting" \| "unknown")` | `Review: Approved` (`.badge-approved`) · `Delivery: Unconfirmed prior attempt ({status}) - do not retry blindly` (`.badge-unknown`) | Core `allows_new_attempt() == false` (`studio.rs:929-935` converts persisted `Posting` to `Unknown` and refuses blind retry). **Suppress/disable publish/retry controls for this revision** and instruct the operator to check the platform account before taking action. |
| `approved` | `Some("posted")` | `Review: Approved` (`.badge-approved`) · `Delivery: Posted recorded` (`.badge-posted`) | Core `allows_new_attempt() == false` for `OPERATION_PUBLISH`. Shows `post_id`/`post_url` when rendered from `POST /review/{id}/publish` (and on `GET` shows that `publish_status` is `"posted"` without inventing unstored receipt fields); **do not advertise `Publish` as a new send**. |
| `approved` | `Some("exported")` | `Review: Approved` (`.badge-approved`) · `Delivery: Last operation exported local bundle (export creates local files only)` (`.badge-exported`) | Clarifies that `export:{target}` is an intent-local operation (`studio.rs:425-464`) that writes local files only and overwrites `publish_status` (`studio.rs:798-816`), without claiming no prior publish intent existed or blocking a separate `OPERATION_PUBLISH` check in core. |

---

## 5. Honest Approximate Local Preview Specification (Surface 2)

On `GET /review/{piece_id}`, replace the incumbent `.text-phone` mock frame with a clean `<article class="local-preview-card">` that obeys these strict honesty rules:

1. **Explicit Local-Preview Header:**
   - Displays **`Approximate local preview · {Channel::display_name}`** and subtitle **`Local system-font rendering; does not verify live remote layout, fonts, or truncation folds.`**
   - When `piece.routing` is `Some(contract)`: displays **`Suggested review target: {escape(&contract.destination.handle)} ({en|es})`** (do **not** prepend an extra `@`, because `crates/syncloom-core/src/routing.rs:156-160` already includes `@` in `contract.destination.handle`), with note `Derived from source-thought language; not a connected account`, plus `Thesis` (`contract.thesis`), `Visual hook` (`contract.visual_hook`), and `Products` (`contract.products`).
   - When `piece.routing` is `None` (legacy piece): displays **`Suggested review target: not recorded`** (never an invented `Founder account`).
2. **Verbatim Draft Text (`.preview-prose`):**
   - Renders `syncloom_core::html::escape(&piece.text)` completely and untruncated with `white-space: pre-wrap; overflow-wrap: break-word; font-size: var(--prose-size); line-height: var(--prose-leading); letter-spacing: var(--prose-tracking); max-width: var(--prose-measure);`.
3. **Conservative App Fit & Cost Footer:**
   - Displays **`Conservative app fit check: {piece.fit.char_count} / {piece.fit.max_chars} {channel.count_unit()} ({piece.fit.verdict})`** (and for `Channel::Bluesky`, also displays `{piece.text.len()} / 3,000 UTF-8 bytes`).
   - For `Channel::X`, displays `CostEstimate` as **`Dated local estimate: {cost.usd()} (pricing as of {cost.pricing_as_of}) · estimate, not an actual charge`**.
4. **Conditional Visual Assets Section:**
   - Only render the PNG/PDF/slide `<img>`/`<iframe>` preview grid when `piece.assets.is_some()` or `piece.visual.is_some()`. For text-only pieces (`visual.is_none()` and `assets.is_none()`), keep `Configure visual slides` as a secondary action link rather than rendering an empty placeholder box.

---

## 6. Dependency-Ordered Implementation Plan & Verification Gate for `syncloom-text-ui`

1. **Step 1 (OpenSpec & Impeccable Preservation):**
   - Create `openspec/changes/add-text-studio-frontend/` linking back to `docs/decisions/0007-text-studio-frontend-stack.md` and `docs/decisions/0008-text-studio-palette-and-typography.md`. Run all OpenSpec commands with `OPENSPEC_TELEMETRY=0 DO_NOT_TRACK=1`.
   - Copy the 18 verified files from `data/syncloom-text-ui-challenge/impeccable-source/` into `docs/design/impeccable/` and verify SHA-256 + byte counts match Section 3.
2. **Step 2 (Modularize `page.rs` & Update `studio.css`):**
   - Split `crates/syncloom-server/src/page.rs` into `crates/syncloom-server/src/page/{mod.rs,home.rs,review.rs}`. Keep `syncloom_core::html::escape` as the single escaping owner across small, directly auditable render functions, backed by inert-output regression tests in `crates/syncloom-server/tests/review_screen.rs` asserting `<`, `>`, `&`, `"`, and `'` in thought, draft, slide, and routing fields render as entity-escaped text (do not build a custom type/template wrapper to claim compile-time safety; if keeping dynamic output auditable in `S1` proves fragile, switch to `S2` per `0007`).
   - Update `crates/syncloom-server/src/studio.css` with the Section 4 tokens and rules (using case-consistent `--accent-tint` in both light and dark blocks).
3. **Step 3 (Deterministic Multi-Channel Thought Form Parsing, Composed Two-Axis Status Display, and Honest Local Previews):**
   - Update `POST /actions/thought` (`page/home.rs`) to parse the `application/x-www-form-urlencoded` body sequentially (`url::form_urlencoded::parse`) after `boundary.rs`'s single-`csrf` check (`boundary.rs:45-96, 119-135`): reject any unknown field name (`!= "csrf" && != "text" && != "channels"`) with `400 invalid_request` (preserving strict unknown-field rejection matching `deny_unknown_fields`), require **exactly one** `text` field (`400 invalid_request` if missing or duplicated), collect all `channels` fields in submission order into `Vec<String>` (never using a last-value-wins map), and pass the collected `Vec<String>` to `Studio::create_thought` (`studio.rs:496-504`, which delegates channel validation to `Studio::parse_channels` at `studio.rs:164-177`). Default the `linkedin_text` checkbox to `checked` in the HTML form on `GET /`.
   - Keep `GET /` pagination on existing `Cursor { after: Option<String> }` (`deny_unknown_fields`, `page.rs:110-145`) backed by `Studio::list` (`studio.rs:556`), with no template-side `/?status=...&channel=...` filtering and no unbacked cross-page sibling group navigation.
   - Render composed `(Piece.status, Piece.publish_status)` badges and action rules on `GET /` and `GET /review/{id}` (Section 4.3), including intent-local `contained`/`exported` wording, `"posting"`/`"unknown"` unconfirmed-attempt no-blind-retry, `"posted"` no-new-send, honest `GET` vs `POST` receipt availability, and `Piece.routing` (`{escape(&contract.destination.handle)}` when `Some` per `routing.rs:13,147-174`, `not recorded` when `None`).
4. **Step 4 (Product Screenshot & Impeccable Critique/Audit Matrix):**
   - Run `cargo fmt --check && cargo clippy --all-targets -- -D warnings && cargo test` and `verify.py`.
   - Start `syncloom-server` + `fake_claude` on synthetic data covering `linkedin_text`, `x`, `bluesky`, `threads`, and `manual_export` across `pending_review`, `approved`, `rejected`, `contained`, `posted`, and `unknown` states.
   - Capture full-page screenshots and computed-style receipts in regular Chrome (`chrome-devtools-axi`) across **all 4 route surfaces + shared error view in Light and Dark mode at `1440x900` and `390x844` (20 captures total)**, verifying:
     - Every normal-text pair >= `4.5:1` and large-text/control/focus pair >= `3.0:1`.
     - Computed `.prose` / `.preview-prose` `line-height` is `26.88px` in Light and `27.52px` (`1.72`) in Dark.
     - `scrollWidth <= clientWidth` and zero clipped/truncated buttons or words on every capture.
     - Document an explicit Impeccable `critique` + `audit` check on every built page before landing.
